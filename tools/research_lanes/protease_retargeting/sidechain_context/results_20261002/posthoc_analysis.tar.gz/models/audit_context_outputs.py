#!/usr/bin/env python3
"""Read-only assigned-output audit. Run only after retrieval is authorized; no endpoints or sampling."""
import argparse,copy,hashlib,importlib.metadata,json,sys,traceback
from pathlib import Path
SC='1e764d610d69a29b76b942c625b6950ec0eb4f4ca0ea30cc0b2fc91cdd11bca2'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def require(ok,msg):
 if not ok:raise ValueError(msg)
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--experiment',type=Path,required=True);ap.add_argument('--package',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
 require(not args.output.exists(),'Output must be new');report={'status':'failed_or_incomplete_audit','model_execution':False,'assigned_candidates':8,'assigned_RF3_outputs':80,'assigned_RF3_inputs':16,'checker_sha256':sha(__file__),'candidates':[],'outputs':[],'errors':[]}
 try:
  import numpy as np
  sys.path.insert(0,str(args.package.parent/'water_conditioning'));import run_prospective_designs as frozen
  exp=args.experiment.resolve();package=args.package.resolve();plan=json.loads((package/'prospective_context_comparison.json').read_text());manifest=json.loads((exp/'candidate_manifest.json').read_text())
  expected={a['id']:a for a in plan['assignments']};candidates={c['id']:c for c in manifest['candidates']};require(len(expected)==8 and set(candidates)==set(expected),'Assigned candidate set changed')
  require(manifest['runner_sha256']==sha(package/'run_context_comparison.py'),'Runner bytes changed');require(manifest['decision_sha256']==sha(package/'prospective_context_comparison.json'),'Decision bytes changed');require(manifest['shared_consumer_sha256']==sha(package.parent/'water_conditioning/run_prospective_designs.py'),'Frozen consumer bytes changed')
  report['outputs']=[{'candidate':cid,'state':state,'seed':0,'sample':sample,'status':'not_audited_missing_candidate_or_input'} for cid in expected for state in ('monomer','ES') for sample in range(5)]
  cr=exp.parent/'native_context_verified.json';context_receipt=json.loads(cr.read_text());require(sha(cr)==manifest['native_context_receipt']['sha256'] and context_receipt['status']=='passed_native_context_pair' and context_receipt['scaffold_sha256']==SC,'Native context receipt mismatch');report['native_context_receipt_sha256']=sha(cr)
  source=package/'selected_scaffold.cif.gz';require(sha(source)==SC,'Scaffold changed');ref=frozen.native_array(source);ref_atoms={(str(ref.chain_id[i]),int(ref.res_id[i]),str(ref.atom_name[i])):ref.coord[i] for i in range(len(ref))}
  report.update(candidate_manifest_sha256=sha(exp/'candidate_manifest.json'),decision_sha256=sha(package/'prospective_context_comparison.json'),rf3_worker_sha256=sha(package/'rf3_seeded_worker.py'),scaffold_sha256=SC,versions={x:importlib.metadata.version(x) for x in ('atomworks','biotite','numpy')})
  normalized=[];names=set();assigned_names=[]
  for cid,a in expected.items():
   c=candidates[cid];folder=exp/'candidates'/cid;row={'id':cid,'status':'failed'}
   try:
    for key in ('arm','pair_seed','mpnn_seed','atomize_side_chains'):require(c[key]==a[key],f'Assignment changed: {cid}/{key}')
    path=folder/'mpnn_config.json';cfg=json.loads(path.read_text());require(len(cfg['inputs'])==1,'MPNN input count changed');inp=cfg['inputs'][0]
    require(c['scaffold_sha256']==SC and Path(inp['structure_path']).name=='selected_scaffold.cif.gz','Configured scaffold changed')
    require(inp['name']==cid and inp['seed']==a['mpnn_seed'] and inp['atomize_side_chains'] is a['atomize_side_chains'],'MPNN assignment mismatch')
    require(inp['fixed_residues']==[f'A{x}' for x in frozen.ROLES]+[f'B{x}' for x in range(1,13)],'Fixed residue set changed')
    require(inp['batch_size']==inp['number_of_batches']==1 and inp['temperature']==0.1 and inp['structure_noise']==0.0 and inp['remove_ccds']==[] and inp['remove_waters'] is False,'MPNN settings changed')
    norm=copy.deepcopy(cfg);norm.pop('out_directory');norm['checkpoint_path']=Path(norm['checkpoint_path']).name
    for key in ('name','seed','atomize_side_chains','structure_path'):norm['inputs'][0].pop(key)
    normalized.append(norm);row['mpnn_config_sha256']=sha(path)
    gate=folder/'mpnn_native_gate.json';g=json.loads(gate.read_text());require(g['status']=='passed_native_mpnn_input_gate' and g['fixed_A_positions']==list(frozen.ROLES) and g['fixed_B_positions']==list(range(1,13)),'MPNN gate receipt changed');row['native_mpnn_gate_sha256']=sha(gate)
    files=list((folder/'mpnn').glob('*.cif'));require(len(files)==1 and files[0].name==f'{cid}_b0_d0.cif','Unexpected MPNN output set');p=files[0];require(sha(p)==c['mpnn_output_sha256'],'MPNN output hash mismatch')
    atoms=frozen.native_array(p);identity=frozen.identities(atoms,c['enzyme_sequence']);require(hashlib.sha256(c['enzyme_sequence'].encode()).hexdigest()==c['enzyme_sha256'],'Enzyme hash mismatch')
    coords={(str(atoms.chain_id[i]),int(atoms.res_id[i]),str(atoms.atom_name[i])):atoms.coord[i] for i in range(len(atoms))}
    required=[k for k,v in ref_atoms.items() if np.isfinite(v).all() and ((k[0]=='A' and (k[1] in frozen.ROLES or k[2] in ('N','CA','C','O'))) or k[0] in ('B','C'))]
    require(all(k in coords and np.isfinite(coords[k]).all() for k in required),'Retained coordinate missing');max_shift=max(float(np.linalg.norm(coords[k]-ref_atoms[k])) for k in required);require(max_shift==0.,'MPNN moved a retained coordinate')
    row.update(status='passed',mpnn_output_sha256=sha(p),native_identity=identity,enzyme_sha256=c['enzyme_sha256'],retained_coordinates_compared=len(required),maximum_retained_coordinate_displacement_A=max_shift)
    require(len(c['rf3_assignments'])==10,'RF3 assignment count changed');require({(x['state'],x['seed'],x['sample']) for x in c['rf3_assignments']}=={(state,0,sample) for state in ('monomer','ES') for sample in range(5)},'RF3 assigned slots changed')
    for state in ('monomer','ES'):
     inp_path=folder/f'rf3_{state}.json';data=json.loads(inp_path.read_text());name=f'{cid}_{state}';assigned_names.append(name);require(data['name']==name and name not in names,'RF3 input name changed/duplicated');names.add(name)
     components=[{'seq':c['enzyme_sequence'],'chain_id':'A'}]+([{'seq':frozen.TARGET,'chain_id':'B'},{'smiles':'[Zn+2].O','chain_id':'C'}] if state=='ES' else [])
     require(set(data)=={'name','components'} and data['components']==components,'RF3 conditioning/components changed')
     for sample in range(5):
      observation=next(x for x in report['outputs'] if (x['candidate'],x['state'],x['sample'])==(cid,state,sample));observation['status']='failed_or_missing'
      try:
       matches=list((exp/'rf3/predictions'/name).rglob(f'{name}_seed-0_sample-{sample}_model.cif'));require(len(matches)==1,'Assigned output missing/ambiguous');p=matches[0];assignment=next(x for x in c['rf3_assignments'] if x['state']==state and x['sample']==sample);require(sha(p)==assignment['sha256'],'Prediction hash mismatch')
       ident=frozen.identities(frozen.native_array(p),c['enzyme_sequence'],es=state=='ES');observation.update(status='passed',path=str(p),sha256=sha(p),residue_counts=ident['residue_counts'],ligand=ident.get('ligand'))
      except Exception as err:observation['error']=f'{type(err).__name__}: {err}'
   except Exception as err:row.update(status='failed',error=f'{type(err).__name__}: {err}')
   report['candidates'].append(row)
  require(len(normalized)==8 and all(x==normalized[0] for x in normalized),'MPNN configs differ beyond declared switch/seed/name/paths')
  reset_path=exp/'rf3/rf3_rng_reset_receipt.json';reset=json.loads(reset_path.read_text());require(reset['reset_before_materialization'] is True and reset['reset_before_each_single_input_run'] is True and reset['engine_reused'] is True and reset['additional_outputs']==0,'RNG control receipt changed')
  require(reset['method']=='lightning.fabric.seed_everything(0, workers=True, verbose=True)','RNG method changed');records=reset['inputs'];require(len(records)==16 and {x['example_id'] for x in records}==set(assigned_names),'RNG input set mismatch')
  require(all(x['seed']==0 and x['assigned_samples']==list(range(5)) and x['status']=='native_run_returned' and x['finished_unix']>=x['started_unix'] for x in records),'RNG call incomplete or changed')
  ng=exp/'rf3/rf3_native_gate.json';nr=json.loads(ng.read_text());require(nr['status']=='passed_native_input_gate_before_weight_loading' and len(nr['inputs'])==16 and {x['id'] for x in nr['inputs']}==set(assigned_names),'RF3 native gate input set changed')
  report['rng_reset_receipt']={'sha256':sha(reset_path),'native_base_source_sha256':reset['native_base_source_sha256'],'completed_single_input_calls':16,'scope':reset['scope']};report['rf3_native_gate_sha256']=sha(ng)
  report['passed_candidates']=sum(x['status']=='passed' for x in report['candidates']);report['passed_RF3_outputs']=sum(x['status']=='passed' for x in report['outputs'])
  if report['passed_candidates']==8 and report['passed_RF3_outputs']==80:report['status']='passed_complete_sidechain_identity_audit'
  report['claim_boundary']='Identity, provenance, assigned-output accounting, unchanged MPNN coordinates and recorded RNG reset only. No primary endpoint evaluation, geometry ranking, activity inference or additional sampling. Reset receipts do not establish bitwise GPU determinism or atom-matched noise.'
 except Exception:report['errors'].append(traceback.format_exc())
 finally:
  with args.output.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
  print(json.dumps({'status':report['status'],'output':str(args.output),'sha256':sha(args.output)}))
if __name__=='__main__':main()

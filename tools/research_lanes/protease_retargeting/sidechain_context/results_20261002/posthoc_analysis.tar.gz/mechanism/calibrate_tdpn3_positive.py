#!/usr/bin/env python3
"""Retrospective measurement of the20 completed TDPn3 outputs; no inference."""
import argparse
import hashlib
import json
from pathlib import Path
import statistics
import sys
import numpy as np
from biotite.structure.io import pdb
sys.dont_write_bytecode = True
ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument("--repo", type=Path, default=Path(__file__).resolve().parents[4])
ap.add_argument("--prior-output", type=Path, help="Extracted prior result_bundle.tar.gz/output directory")
ap.add_argument("--reference-pdb", type=Path)
ap.add_argument("--input-12mer", type=Path)
ap.add_argument("--output", type=Path, default=Path(__file__).with_name("tdpn3_positive_reference_calibration.json"))
args = ap.parse_args()
repo = args.repo.resolve()
lane = repo / "tools/research_lanes/protease_retargeting"
sys.path.insert(0, str(lane / "water_conditioning"))
import window_metrics as w
from measure_water_recovery import fit_transform

sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = args.reference_pdb or lane / "models/TDPn3-author-complex-seed-1-sample-3-filtered.pdb"
assert sha(source) == "a25ad433f43762e4fec54eb4cdb3043ea338131b3f1b9ea2a01748b13683341f"
input12 = args.input_12mer or lane / "window_check/tdpn3_rf3_window_12mer.json"
seq = json.loads(input12.read_text())["components"][0]["seq"]
assert hashlib.sha256(seq.encode()).hexdigest() == w.ENZYME_SHA
old_output = args.prior_output or repo / ".git/catalytic-earth-runs/20261002T153616Z-problem8-continuation/retrieved/bundle/output"
def source_label(path):
    try:
        return str(path.resolve().relative_to(repo))
    except ValueError:
        return str(path.resolve())
groups = {
    "zinc": [["ligand", 1, "ZN"]], "water": [["ligand", 1, "O"]],
    "histidine_146": [["enzyme", 146, "NE2"]], "histidine_150": [["enzyme", 150, "NE2"]],
    "metal_glutamate_45": [["enzyme", 45, a] for a in ("CD", "OE1", "OE2")],
    "general_base_147": [["enzyme", 147, a] for a in ("CD", "OE1", "OE2")],
    "tyrosine_78": [["enzyme", 78, a] for a in ("CZ", "OH")],
    "reactive_backbone": [["peptide", p, a] for p in (7, 8) for a in ("N", "CA", "C", "O")],
}

def arrays(atoms, peptide):
    _, chains = w.identify(atoms, seq, peptide)
    by_key = {(a["chain"], a["residue_number"], a["insertion_code"], a["atom_name"]): a for a in atoms}
    def atom(role, pos, name):
        if role == "ligand":
            matches = [a for a in atoms if a["chain"] not in {c["chain"] for c in chains.values()} and a["element"] == name]
            assert len(matches) == 1
            return matches[0]
        number, insertion = chains[role]["residue_numbers"][pos-1]
        return by_key[(chains[role]["chain"], number, insertion, name)]
    ca = np.asarray([atom("enzyme", p, "CA")["coordinates_angstrom"] for p in range(1,188)])
    group_atoms = {g: [atom(*a) for a in specs] for g,specs in groups.items()}
    return ca, {g: np.asarray([a["coordinates_angstrom"] for a in aa]) for g,aa in group_atoms.items()}, group_atoms

array = pdb.get_structure(pdb.PDBFile.read(source), model=1, altloc="all")
source_atoms = [{"model_state": "author_selected_TDPn3_AF3_ES", "chain": str(array.chain_id[i]),
                 "residue_number": int(array.res_id[i]), "insertion_code": str(array.ins_code[i]),
                 "residue_name": str(array.res_name[i]), "atom_name": str(array.atom_name[i]),
                 "element": str(array.element[i]).upper(), "coordinates_angstrom": list(map(float,array.coord[i]))}
                for i in range(len(array))]
ref_ca, ref, refs = arrays(source_atoms, "ALQSSWGMMG")
rows = []
for length in (10,12):
    peptide = "ALQSSWGMMGML"[:length]
    name = f"TDPn3_ES_window_{length}mer"
    for seed in (0,1):
        for sample in range(5):
            p = old_output / f"seed-{seed}/predictions/{name}/seed-{seed}_sample-{sample}/{name}_seed-{seed}_sample-{sample}_model.cif"
            ca, values, _ = arrays(w.cif_atoms(p, name), peptide)
            rotation,cx,cy,rmsd = fit_transform(ca,ref_ca)
            measured, permutations = {},{}
            for g in groups:
                moved = (values[g]-cx) @ rotation+cy
                orders = [list(range(len(ref[g])))]
                if g in ("metal_glutamate_45", "general_base_147"):
                    orders.append([0,2,1])
                errors = [float(np.sqrt(np.mean(np.sum((moved-ref[g][order])**2,axis=1)))) for order in orders]
                best = int(np.argmin(errors)); measured[g],permutations[g] = errors[best],orders[best]
            rows.append({"peptide_length":length,"seed":seed,"sample":sample,"path_relative_to_prior_output":str(p.relative_to(old_output)),"sha256":sha(p),
                         "enzyme_CA_rmsd_to_own_author_ES_A":rmsd,"group_rmsd_A":measured,"worst_group_rmsd_A":max(measured.values()),
                         "worst_group":max(measured,key=measured.get),"reference_atom_permutations":permutations})
summaries = []
for length in (10,12):
    for seed in (0,1):
        subset = [r for r in rows if r["peptide_length"] == length and r["seed"] == seed]
        summaries.append({"peptide_length":length,"seed":seed,"n":len(subset),
                          "median_worst_group_rmsd_A":statistics.median(r["worst_group_rmsd_A"] for r in subset),
                          "median_enzyme_CA_rmsd_A":statistics.median(r["enzyme_CA_rmsd_to_own_author_ES_A"] for r in subset),
                          "group_median_rmsd_A":{g:statistics.median(r["group_rmsd_A"][g] for r in subset) for g in groups}})
report = {"scope":"Retrospective positive-only context using already completed outputs; no new model execution and no inspection of the new sidechain-context predictions.",
          "reference":{"path":source_label(source),"sha256":sha(source),"state":"Author-selected AF3 ES, not experimental geometry; ten-mer substrate"},
          "prior_raw_archive":{"path_relative_to_repo":"tools/research_lanes/protease_retargeting/window_check/results_20261002/result_bundle.tar.gz","sha256":"6a09d98e8145b7805de35fc0a12b6d9a115cef57a85a66abe598fe33e184dc82","bytes":3402300,"extraction":"Pass its extracted output directory as --prior-output; sample paths in this record are relative to that directory."},
          "enzyme_sequence_sha256":w.ENZYME_SHA,"input_12mer_sha256":sha(input12),
          "method":"Same eight-role worst-group RMSD operation: one proper all187-enzyme-CA fit, separate symmetry-aware Glu groups, max group RMSD. TDPn3-specific H146/H150/E45/E147/Y78 mapping is used against its own sequence-identical author reference. No mapping to the new H36/H40/E152/E37/Y115 scaffold is performed.",
          "comparison_limit":"The reference types differ (selected AF3 model here versus imposed RFD3 scaffold in the new experiment); numerical scores are diagnostic context, not cross-scaffold activity rankings. Only shared G7/M8 backbone is scored, so missing source M11/L12 is not filled. Exposed positive data cannot define a validated classifier threshold.",
          "ordered_reference_atoms":{g:[w.atom_ref(a) for a in aa] for g,aa in refs.items()},"groups":groups,
          "assigned_prior_outputs":20,"measured_prior_outputs":len(rows),"summaries":summaries,"outputs":rows}
out = args.output
out.write_text(json.dumps(report,indent=2,allow_nan=False)+"\n")
print(json.dumps({"output":str(out),"sha256":sha(out),"summaries":summaries},indent=2))

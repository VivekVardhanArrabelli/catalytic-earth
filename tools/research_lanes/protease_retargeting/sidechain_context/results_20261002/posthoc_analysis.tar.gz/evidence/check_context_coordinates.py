#!/usr/bin/env python3
"""Independent raw-CIF audit of the frozen eight-group context comparison.

No primary measurement imports, model execution, output selection or file edits.
Remote paths are mapped to an immutable local extraction without rewriting it.
"""
import argparse
import gzip
import hashlib
import json
import statistics
from pathlib import Path

import numpy as np
from biotite.structure.io import pdbx

AA = dict(zip('ALA ARG ASN ASP CYS GLN GLU GLY HIS ILE LEU LYS MET PHE PRO SER THR TRP TYR VAL'.split(), 'ARNDCQEGHILKMFPSTWYV'))
TARGET = 'ALQSSWGMMGML'
ROLES = {36: 'H', 37: 'E', 40: 'H', 115: 'Y', 152: 'E'}
GROUPS = {
    'zinc': [('ligand', 1, 'ZN')],
    'water': [('ligand', 1, 'O')],
    'histidine_36': [('enzyme', 36, 'NE2')],
    'histidine_40': [('enzyme', 40, 'NE2')],
    'metal_glutamate_152': [('enzyme', 152, x) for x in ('CD', 'OE1', 'OE2')],
    'general_base_37': [('enzyme', 37, x) for x in ('CD', 'OE1', 'OE2')],
    'tyrosine_115': [('enzyme', 115, x) for x in ('CZ', 'OH')],
    'reactive_backbone': [('peptide', r, x) for r in (7, 8) for x in ('N', 'CA', 'C', 'O')],
}
GLUTAMATES = {'metal_glutamate_152', 'general_base_37'}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_json(path):
    return json.loads(Path(path).read_text())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def structure(path, enzyme_sequence=None, state='ES', reference=False):
    with (gzip.open(path, 'rt') if str(path).endswith('.gz') else Path(path).open()) as stream:
        cif = pdbx.CIFFile.read(stream)
    require(len(set(cif.block['atom_site']['pdbx_PDB_model_num'].as_array(str))) == 1, 'CIF contains multiple models')
    atoms = pdbx.get_structure(cif, model=1, use_author_fields=False, altloc='all')
    residues, points, elements = {}, {}, {}
    for a in atoms:
        ch, res, name = str(a.chain_id), int(a.res_id), str(a.atom_name)
        require(not str(a.ins_code).strip(), 'Insertion code would make sequence position ambiguous')
        key = (ch, res, name)
        require(key not in points, f'Duplicate atom identity {key}')
        points[key] = np.asarray(a.coord, dtype=float)
        elements[key] = str(a.element).upper()
        residue_key = (ch, res)
        require(residue_key not in residues or residues[residue_key] == str(a.res_name), 'Conflicting residue identity')
        residues[residue_key] = str(a.res_name)
    chains = {ch for ch, _ in residues}
    sequences = {ch: ''.join(AA.get(residues[ch, r], '?') for r in sorted(r for c, r in residues if c == ch)) for ch in chains}
    if reference:
        enzyme = 'A'
        require(enzyme in sequences and len(sequences[enzyme]) == 187 and '?' not in sequences[enzyme], 'Reference enzyme A is not canonical length187')
        enzyme_sequence = sequences[enzyme]
    else:
        found = [ch for ch, seq in sequences.items() if seq == enzyme_sequence]
        require(len(found) == 1, 'Enzyme does not have one exact sequence match')
        enzyme = found[0]
    require(sorted(r for ch, r in residues if ch == enzyme) == list(range(1, 188)), 'Enzyme positions are not1..187')
    require(all(enzyme_sequence[r-1] == aa for r, aa in ROLES.items()), 'Fixed enzyme roles changed')
    ca = np.array([points[enzyme, r, 'CA'] for r in range(1, 188)])
    require(np.isfinite(ca).all(), 'Nonfinite fitted CA coordinate')
    if state == 'monomer':
        require(chains == {enzyme}, 'Monomer has unexpected additional chains')
        return {'ca': ca, 'enzyme_chain': enzyme, 'enzyme_sequence': enzyme_sequence}
    found = [ch for ch, seq in sequences.items() if seq == TARGET]
    require(len(found) == 1 and found[0] != enzyme, 'Peptide does not have one exact sequence match')
    peptide = found[0]
    require(sorted(r for ch, r in residues if ch == peptide) == list(range(1, 13)), 'Peptide positions are not1..12')
    if reference:
        require(peptide == 'B', 'Reference peptide chain changed')
    ligand = [key for key in points if key[0] not in (enzyme, peptide) and elements[key] not in ('H', 'D')]
    require(sorted(elements[key] for key in ligand) == ['O', 'ZN'], 'Ligand heavy species are not exactly oneZn and oneO')
    if reference:
        require(all(key[0] == 'C' for key in ligand), 'Reference ligand chain changed')
    lpoints = {elements[key]: points[key] for key in ligand}
    groups = {}
    for name, members in GROUPS.items():
        groups[name] = np.array([lpoints[atom] if role == 'ligand' else points[enzyme if role == 'enzyme' else peptide, res, atom] for role, res, atom in members])
        require(np.isfinite(groups[name]).all(), f'Nonfinite scored coordinate in {name}')
    return {'ca': ca, 'groups': groups, 'enzyme_chain': enzyme, 'peptide_chain': peptide, 'enzyme_sequence': enzyme_sequence}


def fit_to_reference(prediction, reference):
    """Inverse covariance orientation; one proper enzyme-CA transform only."""
    pm, rm = prediction.mean(axis=0), reference.mean(axis=0)
    X, Y = prediction - pm, reference - rm
    covariance = Y.T @ X
    require(np.linalg.matrix_rank(covariance) >= 2, 'Undefined rigid fit')
    U, singular, Vh = np.linalg.svd(covariance)
    correction = np.diag([1., 1., 1. if np.linalg.det(Vh.T @ U.T) >= 0 else -1.])
    rotation = Vh.T @ correction @ U.T
    require(np.linalg.det(rotation) > 0, 'Fit contains reflection')
    rmsd = float(np.sqrt(np.mean(np.sum((X @ rotation - Y)**2, axis=1))))
    return rotation, pm, rm, rmsd


def metric(prediction, reference):
    rotation, pm, rm, ca_rmsd = fit_to_reference(prediction['ca'], reference['ca'])
    group_rmsds, permutations = {}, {}
    for name in GROUPS:
        moved = (prediction['groups'][name] - pm) @ rotation + rm
        target = reference['groups'][name]
        identity = float(np.sqrt(np.mean(np.sum((moved - target)**2, axis=1))))
        value = identity
        if name in GLUTAMATES:
            swapped = float(np.sqrt(np.mean(np.sum((moved[[0, 2, 1]] - target)**2, axis=1))))
            choose_swap = swapped < identity
            value = swapped if choose_swap else identity
            permutations[name] = {'selected': 'OE1_OE2_swap' if choose_swap else 'identity', 'identity_rmsd_A': identity, 'swap_rmsd_A': swapped}
        group_rmsds[name] = value
    return {'group_rmsd_A': group_rmsds, 'worst_group_rmsd_A': max(group_rmsds.values()), 'enzyme_CA_rmsd_A': ca_rmsd, 'glutamate_permutations': permutations, 'rotation_determinant': float(np.linalg.det(rotation))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('manifest', 'plan', 'reference', 'extraction-root', 'remote-root', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    manifest, plan = load_json(args.manifest), load_json(args.plan)
    require(digest(args.reference) == plan['reference_scaffold']['sha256'], 'Reference scaffold differs from frozen plan')
    require(plan['primary']['groups'] == {key: [list(x) for x in value] for key, value in GROUPS.items()}, 'Frozen group definition differs')
    require(plan['target']['sequence'] == TARGET and plan['target']['enzyme_length'] == 187, 'Frozen target differs')
    require(plan['shared_sampling']['rf3_seed'] == 0 and plan['shared_sampling']['rf3_ES_samples_per_sequence'] == 5 and plan['shared_sampling']['rf3_monomer_samples_per_sequence'] == 5, 'Frozen RF3 assignments differ')
    tolerance = plan['primary']['numerical_tolerance_A']
    require(tolerance == 1e-6, 'Frozen numerical tolerance differs')
    expected_ids = [f'context_{arm}_seed{seed}' for seed in range(200, 204) for arm in ('hidden', 'revealed')]
    require([a['id'] for a in plan['assignments']] == expected_ids, 'Frozen sequence assignment set differs')
    reference = structure(args.reference, reference=True)
    def local(path):
        require(path is not None, 'Assigned path absent')
        return args.extraction_root / Path(path).relative_to(args.remote_root)
    errors = []
    if manifest.get('decision_sha256') != digest(args.plan):
        errors.append('Manifest frozen decision hash differs')
    candidate_ids = [c['id'] for c in manifest['candidates']]
    if sorted(candidate_ids) != sorted(expected_ids):
        errors.append('Manifest candidate IDs differ from frozen assignments')
    for field, expected in [('assigned_candidates', 8), ('assigned_RF3_outputs', 80), ('primary_assigned_ES_outputs', 40)]:
        if manifest.get(field) != expected:
            errors.append(f'Manifest {field} differs from{expected}')
    seen_paths, candidates = set(), []
    counts = {state: {'assigned': 40, 'manifest_produced': 0, 'hash_verified': 0, 'identity_valid': 0, 'metric_valid': 0} for state in ('ES', 'monomer')}
    for assignment in plan['assignments']:
        matches = [c for c in manifest['candidates'] if c['id'] == assignment['id']]
        c = matches[0] if len(matches) == 1 else {}
        row = {**assignment, 'sequence_sha256': c.get('enzyme_sha256'), 'outputs': [], 'candidate_errors': []}
        seq = c.get('enzyme_sequence')
        try:
            require(len(matches) == 1, 'Missing or duplicate candidate')
            for field in ('arm', 'pair_seed', 'mpnn_seed', 'atomize_side_chains'):
                require(c.get(field) == assignment[field], f'Candidate {field} differs')
            require(isinstance(seq, str) and len(seq) == 187 and all(aa in AA.values() for aa in seq), 'Invalid enzyme sequence')
            require(hashlib.sha256(seq.encode()).hexdigest() == c['enzyme_sha256'], 'Enzyme sequence hash differs')
            require(all(seq[r-1] == aa for r, aa in ROLES.items()), 'Catalytic identities differ')
            require(c.get('scaffold_sha256') == digest(args.reference) == digest(local(c['scaffold_path'])), 'Scaffold hash differs')
            require(digest(local(c['mpnn_output_path'])) == c['mpnn_output_sha256'], 'MPNN output hash differs')
            slots = [(a['state'], a['seed'], a['sample']) for a in c['rf3_assignments']]
            expected_slots = [(state, 0, sample) for state in ('monomer', 'ES') for sample in range(5)]
            require(sorted(slots) == sorted(expected_slots), 'Manifest assigned slots differ')
        except (ValueError, KeyError, TypeError, OSError) as exc:
            row['candidate_errors'].append(str(exc))
        for state in ('monomer', 'ES'):
            input_error = None
            try:
                data = load_json(local(c.get('rf3_input_paths', {}).get(state)))
                components = [{'seq': seq, 'chain_id': 'A'}]
                if state == 'ES':
                    components += [{'seq': TARGET, 'chain_id': 'B'}, {'smiles': '[Zn+2].O', 'chain_id': 'C'}]
                require(data == {'name': assignment['id'] + '_' + state, 'components': components}, 'Unconditioned input differs')
            except (ValueError, KeyError, TypeError, OSError) as exc:
                input_error = str(exc)
            for sample in range(5):
                slot = {'state': state, 'seed': 0, 'sample': sample, 'status': 'missing_or_invalid'}
                found = [a for a in c.get('rf3_assignments', []) if (a.get('state'), a.get('seed'), a.get('sample')) == (state, 0, sample)]
                try:
                    require(len(found) == 1, 'Missing or duplicate output assignment')
                    a = found[0]
                    slot['manifest_status'] = a.get('status')
                    require(a.get('status') == 'produced_pending_measurement', 'Assigned output was not uniquely produced')
                    counts[state]['manifest_produced'] += 1
                    path = local(a.get('path'))
                    slot.update(path=str(path), sha256=a.get('sha256'))
                    require(path not in seen_paths, 'Output path reused across assignments')
                    seen_paths.add(path)
                    require(digest(path) == a.get('sha256'), 'CIF hash differs')
                    counts[state]['hash_verified'] += 1
                    exact = f"{assignment['id']}_{state}_seed-0_sample-{sample}_model.cif"
                    require(path.name == exact, 'Output name differs from assigned sample')
                    matches_in_folder = list(local(c['rf3_output_dirs'][state]).rglob(exact))
                    require(len(matches_in_folder) == 1 and matches_in_folder[0] == path, 'Assigned sample path is missing or ambiguous')
                    require(not row['candidate_errors'], '; '.join(row['candidate_errors']))
                    require(input_error is None, input_error)
                    pred = structure(path, seq, state=state)
                    counts[state]['identity_valid'] += 1
                    slot['enzyme_chain'] = pred['enzyme_chain']
                    if state == 'ES':
                        slot.update(metric(pred, reference), peptide_chain=pred['peptide_chain'])
                    else:
                        slot['enzyme_CA_rmsd_A'] = fit_to_reference(pred['ca'], reference['ca'])[3]
                    slot['status'] = 'measured'
                    counts[state]['metric_valid'] += 1
                except (ValueError, KeyError, TypeError, OSError, np.linalg.LinAlgError) as exc:
                    slot['error'] = str(exc)
                row['outputs'].append(slot)
        es = [x for x in row['outputs'] if x['state'] == 'ES']
        row['complete_ES'] = all(x['status'] == 'measured' for x in es)
        row['complete_monomer'] = all(x['status'] == 'measured' for x in row['outputs'] if x['state'] == 'monomer')
        row['median_worst_group_rmsd_A'] = statistics.median(x['worst_group_rmsd_A'] for x in es) if row['complete_ES'] else None
        row['median_group_rmsd_A'] = {g: statistics.median(x['group_rmsd_A'][g] for x in es) for g in GROUPS} if row['complete_ES'] else None
        candidates.append(row)
    pairs = []
    for seed in range(200, 204):
        hidden = next(c for c in candidates if c['pair_seed'] == seed and c['arm'] == 'context_hidden')
        revealed = next(c for c in candidates if c['pair_seed'] == seed and c['arm'] == 'context_revealed')
        row = {'pair_seed': seed, 'complete': hidden['complete_ES'] and revealed['complete_ES']}
        if row['complete']:
            row['hidden_median_W_A'] = hidden['median_worst_group_rmsd_A']
            row['revealed_median_W_A'] = revealed['median_worst_group_rmsd_A']
            row['revealed_minus_hidden_W_A'] = row['revealed_median_W_A'] - row['hidden_median_W_A']
            row['revealed_minus_hidden_group_medians_A'] = {g: revealed['median_group_rmsd_A'][g] - hidden['median_group_rmsd_A'][g] for g in GROUPS}
        pairs.append(row)
    complete = counts['ES']['metric_valid'] == 40 and all(p['complete'] for p in pairs) and not errors
    if not complete:
        decision = 'incomplete_comparison'
    elif all(p['revealed_minus_hidden_W_A'] < -tolerance and all(v <= tolerance for v in p['revealed_minus_hidden_group_medians_A'].values()) for p in pairs):
        decision = 'consistent_revealed_context_reference_recovery_benefit'
    elif all(p['revealed_minus_hidden_W_A'] > tolerance and all(v >= -tolerance for v in p['revealed_minus_hidden_group_medians_A'].values()) for p in pairs):
        decision = 'consistent_hidden_context_reference_recovery_benefit'
    else:
        decision = 'no_consistent_joint_reference_recovery_advantage'
    sequences = [c.get('enzyme_sequence') for c in manifest['candidates'] if c.get('enzyme_sequence')]
    result = {
        'status': 'independent_coordinate_audit_complete' if complete and counts['monomer']['metric_valid'] == 40 else 'independent_coordinate_audit_has_missingness_or_integrity_error',
        'model_execution': False, 'primary_implementation_imported': False,
        'provenance': {'auditor_sha256': digest(__file__), 'manifest_sha256': digest(args.manifest), 'decision_sha256': digest(args.plan), 'reference_sha256': digest(args.reference)},
        'manifest_errors': errors, 'assigned_candidates': 8, 'assigned_outputs': 80, 'counts': counts,
        'unique_enzyme_sequences': len(set(sequences)), 'numerical_tolerance_A': tolerance,
        'decision': decision, 'pairs': pairs, 'candidates': candidates,
        'interpretation': 'Four paired sequence-design seeds on one post hoc selected scaffold; five predictions are correlated outputs. Reference recovery is not activity, folding or Atlas efficacy. No assigned output was selected away or replaced.',
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({k: result[k] for k in ('status', 'manifest_errors', 'counts', 'decision', 'pairs')}, indent=2))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Compare saved independent calculations with immutable primary result data."""
import hashlib,json,statistics
from pathlib import Path
RUN=Path(__file__).resolve().parents[1]
independent_path=RUN/'evidence/independent_context_audit.json'
reported_path=RUN/'retrieved/runtime/experiment/context_recovery_measurements.json'
ind=json.loads(independent_path.read_text());rep=json.loads(reported_path.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert ind['status']=='independent_coordinate_audit_complete'
assert ind['decision']==rep['decision']
assert rep['assigned_candidates']==8 and rep['assigned_ES']==40 and rep['assigned_monomer']==40
assert rep['observed_ES']==40 and rep['observed_monomer_context']==40
assert ind['provenance']['manifest_sha256']==rep['manifest_sha256']
assert ind['provenance']['decision_sha256']==rep['decision_sha256']
assert ind['provenance']['reference_sha256']==rep['reference_scaffold_sha256']
assert sorted(c['id'] for c in ind['candidates'])==sorted(c['id'] for c in rep['candidates'])
maxima={name:0. for name in ('group_RMSD_A','per_output_W_A','candidate_median_W_A','candidate_group_median_A','paired_W_difference_A','paired_group_difference_A','CA_RMSD_A')}
comparisons={name:0 for name in maxima}
def match(name,a,b):
 d=abs(a-b);maxima[name]=max(maxima[name],d);comparisons[name]+=1
 assert d<1e-9,(name,a,b,d)
permutation_checks=0
context=[]
for c in ind['candidates']:
 r=next(x for x in rep['candidates'] if x['id']==c['id'])
 assert r['complete_ES'] and r['observed_ES']==5
 match('candidate_median_W_A',c['median_worst_group_rmsd_A'],r['median_worst_group_rmsd_A'])
 for group,value in c['median_group_rmsd_A'].items():match('candidate_group_median_A',value,r['group_median_rmsd_A'][group])
 for o in c['outputs']:
  assert o['status']=='measured'
  rr=next(x for x in (r['outputs'] if o['state']=='ES' else r['structural_context']['monomer']) if x['sample']==o['sample'] and x['seed']==0)
  assert rr['status']=='measured'
  match('CA_RMSD_A',o['enzyme_CA_rmsd_A'],rr['enzyme_CA_rmsd_to_scaffold_A'])
  if o['state']=='monomer':continue
  assert o['sha256']==rr['sha256']
  match('per_output_W_A',o['worst_group_rmsd_A'],rr['worst_group_rmsd_A'])
  for group,value in o['group_rmsd_A'].items():match('group_RMSD_A',value,rr['group_rmsd_A'][group])
  for group,choice in o['glutamate_permutations'].items():
   expected=[0,2,1] if choice['selected']=='OE1_OE2_swap' else [0,1,2]
   assert rr['reference_atom_permutations'][group]==expected
   permutation_checks+=1
 context.append({'id':c['id'],'median_W_A':c['median_worst_group_rmsd_A'],'median_ES_CA_RMSD_A':statistics.median(o['enzyme_CA_rmsd_A'] for o in c['outputs'] if o['state']=='ES'),'median_monomer_CA_RMSD_A':statistics.median(o['enzyme_CA_rmsd_A'] for o in c['outputs'] if o['state']=='monomer')})
for p in ind['pairs']:
 r=next(x for x in rep['paired_seed_results'] if x['pair_seed']==p['pair_seed'])
 assert p['complete'] and r['complete']
 match('paired_W_difference_A',p['revealed_minus_hidden_W_A'],r['revealed_minus_hidden_median_worst_group_A'])
 for group,value in p['revealed_minus_hidden_group_medians_A'].items():match('paired_group_difference_A',value,r['revealed_minus_hidden_group_median_A'][group])
result={'status':'independent_recomputation_matches_immutable_primary','checker_sha256':sha(RUN/'evidence/check_context_coordinates.py'),'comparison_script_sha256':sha(Path(__file__)),'independent_result_sha256':sha(independent_path),'immutable_primary_result_sha256':sha(reported_path),'assigned_ES':40,'assigned_monomer':40,'observed_ES':40,'observed_monomer':40,'unique_sequence_count':ind['unique_enzyme_sequences'],'all80_CIF_hashes_and_exact_sequence_identities_verified':True,'all16_prediction_input_JSONs_match_unconditioned_assignment':True,'separate_bijective_Glu_permutations_matched':permutation_checks,'max_absolute_discrepancy_A':max(maxima.values()),'maximum_discrepancies_by_measure':maxima,'comparison_counts':comparisons,'decision':ind['decision'],'paired_medians':ind['pairs'],'CA_context':context,'interpretation':'The sole pair with lower revealed-context medianW regresses the general-base and reactive-backbone group medians. Three other pairs have higher medianW with revealed context. Therefore neither arm meets the frozen four-pair joint-recovery rule. This closes this bounded context-ablation comparison; it does not establish biochemical activity, general context harm or equivalence.'}
(RUN/'evidence/independent_context_comparison.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:result[k] for k in ('status','unique_sequence_count','separate_bijective_Glu_permutations_matched','max_absolute_discrepancy_A','decision','CA_context')},indent=2))

#!/usr/bin/env bash
set -uo pipefail
export CE_P8_RUNTIME=/home/ubuntu/ce-sc-20261002/runtime
export CE_P8_PACKAGE=/home/ubuntu/ce-sc-20261002/package/sidechain_context
date -u +%FT%TZ > /home/ubuntu/ce-sc-20261002/bootstrap_started.txt
bash "$CE_P8_PACKAGE/remote_bootstrap.sh"
CE_P8_BOOT_STATUS=$?
echo "$CE_P8_BOOT_STATUS" > /home/ubuntu/ce-sc-20261002/bootstrap_exit_code.txt
date -u +%FT%TZ > /home/ubuntu/ce-sc-20261002/bootstrap_finished.txt
exit "$CE_P8_BOOT_STATUS"

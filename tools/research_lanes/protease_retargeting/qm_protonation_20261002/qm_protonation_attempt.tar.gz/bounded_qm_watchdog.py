"""Enforce the authorized pair's wall/RSS limits; never retry a state."""
from pathlib import Path
import subprocess,os,time,json,hashlib,signal
HERE=Path(__file__).resolve().parent
assert not (HERE/'qm_watchdog.json').exists(),'This frozen pair cannot be rerun'
(HERE/'tmp').mkdir(exist_ok=True)
env=os.environ.copy()
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):env[name]='4'
env.update(PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(HERE/'tmp'))
start=time.monotonic();peak=0;reason=None
with (HERE/'qm_console.log').open('x') as stream:
    process=subprocess.Popen([str(HERE/'venv/bin/python'),str(HERE/'run_protonation_probe.py')],env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    while process.poll() is None:
        elapsed=time.monotonic()-start
        report=subprocess.run(['ps','-o','rss=','-p',str(process.pid)],capture_output=True,text=True)
        try:rss=int(report.stdout.strip())*1024
        except ValueError:rss=0
        peak=max(peak,rss)
        if elapsed>=1800 or rss>4*1024**3:
            reason='1800_second_wall_limit' if elapsed>=1800 else '4_GiB_resident_memory_limit'
            os.killpg(process.pid,signal.SIGTERM)
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL)
            break
        time.sleep(2)
    code=process.wait()
record={'exit_code':code,'termination_reason':reason,'wall_seconds':time.monotonic()-start,'peak_observed_rss_bytes':peak,'rss_sampling_seconds':2,'threads_requested':4,'no_retry':True,'decision_sha256':hashlib.sha256((HERE/'qm_protonation_decision.json').read_bytes()).hexdigest()}
(HERE/'qm_watchdog.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))

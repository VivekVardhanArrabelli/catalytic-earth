"""Run only the frozen two-state, fixed-geometry native PySCF diagnostic."""
from pathlib import Path
import json,hashlib,time,traceback,os,sys
from pyscf import gto,dft,lib
HERE=Path(__file__).resolve().parent
plan=json.loads((HERE/'qm_protonation_decision.json').read_text())
lib.num_threads(4)
results=[];engines=[];start=time.monotonic()

def write_results():
    record={'decision_sha256':hashlib.sha256((HERE/'qm_protonation_decision.json').read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'elapsed_seconds':time.monotonic()-start,'states':results,'usable_vertical_delta_hartree':None,'usable_vertical_delta_kcal_per_mol':None,'contrast':'hydroxide_glutamic_acid minus water_glutamate','scope':plan['interpretation']}
    if len(results)==2 and all(r.get('scf_converged',False) for r in results):
        difference=results[1]['electronic_energy_hartree']-results[0]['electronic_energy_hartree']
        record.update(usable_vertical_delta_hartree=difference,usable_vertical_delta_kcal_per_mol=difference*627.5094740631)
    (HERE/'qm_protonation_results.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    return record

for state in plan['state_files']:
    name=state['name'];path=HERE/f'{name}.json'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==state['json_sha256']
    data=json.loads(path.read_text());row={'name':name,'status':'SCF_running','scf_converged':False};results.append(row);write_results()
    t=time.monotonic()
    try:
        molecule=gto.M(atom=[(a['element'],a['xyz_angstrom']) for a in data['atoms']],unit='Angstrom',charge=0,spin=0,basis='def2-svpd',verbose=4,max_memory=3000,output=str(HERE/f'{name}_pyscf.log'))
        assert molecule.nelectron==238 and molecule.natm==60
        solver=dft.RKS(molecule)
        solver.xc='B3LYP';solver.grids.level=3;solver.conv_tol=1e-8;solver.max_cycle=80;solver.max_memory=3000;solver.direct_scf=True
        solver.chkfile=str(HERE/f'{name}.chk')
        energy=solver.kernel()
        row.update(status='SCF_converged' if solver.converged else 'SCF_not_converged',scf_converged=bool(solver.converged),electronic_energy_hartree=float(energy),basis_functions=molecule.nao_nr(),scf_seconds=time.monotonic()-t)
        engines.append((row,solver))
    except BaseException as exc:
        row.update(status='native_calculation_failed',error=f'{type(exc).__name__}: {exc}',traceback=traceback.format_exc())
    write_results()
# Energies for both states precede gradients, preserving the minimal pair if the
# allowed runtime cannot finish derivative evaluation.
for row,solver in engines:
    if not row['scf_converged']:continue
    row['gradient_status']='running';write_results();t=time.monotonic()
    try:
        gradient=solver.nuc_grad_method().kernel()
        idx=plan['transfer_atom_index_zero_based'];axis=plan['transfer_axis_water_to_E294']
        force_projection=-sum(float(gradient[idx,i])*axis[i] for i in range(3))
        row.update(gradient_status='computed',gradient_hartree_per_bohr=gradient.tolist(),transfer_H_force_toward_E294_hartree_per_bohr=force_projection,gradient_seconds=time.monotonic()-t)
    except BaseException as exc:
        row.update(gradient_status='failed',gradient_error=f'{type(exc).__name__}: {exc}')
    write_results()
print(json.dumps(write_results(),indent=2))

"""Construct a prospectively fixed, source-capped 60-atom electronic-state probe."""
from pathlib import Path
import json,math,hashlib,collections
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[3]
HYBRID=REPO/'.git/catalytic-earth-runs/20261002T153616Z-problem8-continuation/abeta/design_input/251222_motif_with_ANISOU.pdb'
SOURCE=HERE/'GS_complex_small.pdb'

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sub(a,b):return [x-y for x,y in zip(a,b)]
def norm(v):return math.sqrt(sum(x*x for x in v))
def unit(v):return [x/norm(v) for x in v]
def add(a,b):return [x+y for x,y in zip(a,b)]
def scale(v,k):return [x*k for x in v]
def xyz(line):return [float(line[i:i+8]) for i in (30,38,46)]
def read(p):return {(line[21],int(line[22:26]),line[12:16].strip()):xyz(line) for line in p.read_text().splitlines() if line[:6] in ('ATOM  ','HETATM')}
s=read(SOURCE);h=read(HYBRID);atoms=[]
def atom(label,element,coord,provenance):atoms.append({'label':label,'element':element,'xyz_angstrom':coord,'provenance':provenance})
for resid,source_res,kind in ((293,76,'HID'),(297,80,'HID'),(316,156,'GLU'),(294,156,'GLU')):
    heavy=['CA','CB','CG','CD2','ND1','CE1','NE2'] if kind=='HID' else ['CA','CB','CG','CD','OE1','OE2']
    for name in heavy:
        atom(f'A{resid}:{"CH3" if name=="CA" else name}',name[0],h[('A',resid,name)],{'source_chain':'A','source_residue':resid,'source_atom':name,'operation':'CA retained as methyl-cap carbon' if name=='CA' else 'unchanged source heavy atom'})
    for i,direction_name in enumerate(('N','C','HA'),1):
        length=math.dist(s[('A',source_res,f'H{i}')],s[('A',source_res,'CH3')])
        position=add(h[('A',resid,'CA')],scale(unit(sub(h[('A',resid,direction_name)],h[('A',resid,'CA')])),length))
        atom(f'A{resid}:Hcap{i}','H',position,{'operation':'analyst-constructed methyl-cap H using source N/C/HA direction and corresponding author MCPB CH3-H length','length_angstrom':length})
    attachments={'HB2':'CB','HB3':'CB','HD2':'CD2','HE1':'CE1','HD1':'ND1'} if kind=='HID' else {'HB2':'CB','HB3':'CB','HG2':'CG','HG3':'CG'}
    for hydrogen,parent in attachments.items():
        length=math.dist(s[('A',source_res,hydrogen)],s[('A',source_res,parent)])
        position=add(h[('A',resid,parent)],scale(unit(sub(h[('A',resid,hydrogen)],h[('A',resid,parent)])),length))
        atom(f'A{resid}:{hydrogen}','H',position,{'source_atom':hydrogen,'operation':'source hybrid direction, length normalized to same author MCPB atom class','length_angstrom':length})
water=h[('C',1,'O1')]; zinc=h[('C',1,'ZN1')]
acceptor=min(('OE1','OE2'),key=lambda name:math.dist(water,h[('A',294,name)]))
acceptor_xyz=h[('A',294,acceptor)];axis=unit(sub(acceptor_xyz,water))
source_w=s[('A',190,'O')];v1=sub(s[('A',190,'H1')],source_w);v2=sub(s[('A',190,'H2')],source_w)
length=(norm(v1)+norm(v2))/2;theta=math.acos(sum(a*b for a,b in zip(unit(v1),unit(v2))))
away=sub(water,zinc);perp=unit(sub(away,scale(axis,sum(a*b for a,b in zip(away,axis)))))
h2direction=add(scale(axis,math.cos(theta)),scale(perp,math.sin(theta)))
atom('water:O','O',water,{'source_chain':'C','source_residue':1,'source_atom':'O1','operation':'unchanged source heavy atom'})
atom('transfer:H','H',add(water,scale(axis,length)),{'operation':'water H directed to nearest general-base oxygen; length from source MCPB water; analyst-assumed initial orientation','length_angstrom':length})
atom('water:Hfixed','H',add(water,scale(h2direction,length)),{'operation':'second water H uses source MCPB water angle and projects away from Zn','HOH_degrees':math.degrees(theta)})
atom('Zn','Zn',zinc,{'source_chain':'C','source_residue':1,'source_atom':'ZN1','operation':'unchanged source heavy atom'})
second=json.loads(json.dumps(atoms));idx=next(i for i,a in enumerate(atoms) if a['label']=='transfer:H')
second[idx]['xyz_angstrom']=add(acceptor_xyz,scale(axis,-length))
second[idx]['provenance']={'operation':'same existing H moved onto nearest E294 oxygen toward water, using identical O-H length; no atoms added or removed','acceptor':f'A294:{acceptor}','length_angstrom':length}
assert len(atoms)==len(second)==60
counts=dict(collections.Counter(a['element'] for a in atoms));assert counts=={'C':18,'N':4,'H':32,'O':5,'Zn':1}
Z={'H':1,'C':6,'N':7,'O':8,'Zn':30};electrons=sum(Z[a['element']] for a in atoms);assert electrons==238
assert all(a['element']==b['element'] and a['label']==b['label'] and (i==idx or a['xyz_angstrom']==b['xyz_angstrom']) for i,(a,b) in enumerate(zip(atoms,second)))
for name,rows in [('water_glutamate',atoms),('hydroxide_glutamic_acid',second)]:
    p=HERE/f'{name}.xyz'
    with p.open('x') as f:
        f.write(f'{len(rows)}\n{name}; charge0 multiplicity1; source hybrid heavy atoms fixed\n')
        for a in rows:f.write(f"{a['element']:2s} "+' '.join(f'{v:.12f}' for v in a['xyz_angstrom'])+'\n')
    with (HERE/f'{name}.json').open('x') as f:json.dump({'name':name,'charge':0,'spin_2S':0,'atoms':rows},f,indent=2);f.write('\n')
manifest={'status':'frozen before any SCF energy','question':'For this fixed source-hybrid isolated Zn cluster, what vertical electronic-energy and proton-force contrast follows from moving one water proton to the proposed general base?','composition':counts,'total_electrons':238,'charge':0,'spin_2S':0,'multiplicity':1,'fragments':{'H293_H297':'two neutral C5H8N2 HID methyl-capped sidechains; ND1 protonated, NE2 unprotonated','E316':'C4H7O2 carboxylate, -1','E294_state_A':'C4H7O2 carboxylate, -1','Zn':'formal +2, d10 closed-shell chemical assignment','water_state_A':'H2O neutral','state_B_change':'one water H moves to E294, giving OH(-1) plus neutral C4H8O2; global charge unchanged'},'caps':'Author MCPB small.pdb uses CH3 at CA with CB onward retained. New cap-H directions follow hybrid N/C/HA directions; lengths and unchanged sidechain-H classes follow the author small cluster. Cap coordinates are constructed, not author optimized coordinates.','source_files':[{'path':str(p.relative_to(REPO)),'sha256':digest(p)} for p in (HYBRID,SOURCE,HERE/'GS_complex_small_opt.com')],'fixed_geometry':'Every coordinate except transfer:H is identical across states; all coordinates are held fixed during each single-point calculation. No Zn-water, base-water or attack-angle restraint or fitted metal force field is used.','transfer_atom_index_zero_based':idx,'transfer_axis_water_to_E294':axis,'acceptor':f'A294:{acceptor}','water_acceptor_distance_angstrom':math.dist(water,acceptor_xyz),'initial_OH_distance_angstrom':length,'environment':'Isolated vacuum cluster, as in the source Gaussian input without solvent keyword; protein, peptide, Y donor, dielectric screening and conformational entropy are absent. These omissions make this an exploratory local electronic diagnostic, not a protein microstate preference.','method':{'engine':'PySCF2.14.0','functional':'B3LYP using native LibXC definition','basis':'def2-SVPD on all atoms, all-electron Zn','basis_change':'Prospectively chosen complete diffuse basis; native source-named 6-31+G(d) lacks Zn. Not a reproduction of the source Gaussian energy.','grid_level':3,'SCF':'restricted Kohn-Sham, native default DIIS and minao initial guess','conv_tol_hartree':1e-8,'max_cycle':80,'max_memory_MB':3000,'threads':4,'outputs':['SCF convergence and energy','analytic gradient','transfer-H force projected along water-to-E294 axis'],'no_rescue':'Nonconvergence or watchdog termination remains missing; no later method or threshold adjustment.'},'limits':{'wall_seconds_for_pair':1800,'resident_bytes':4*1024**3,'cpu_threads':4},'state_files':[{ 'name':name,'json_sha256':digest(HERE/f'{name}.json'),'xyz_sha256':digest(HERE/f'{name}.xyz')} for name in ('water_glutamate','hydroxide_glutamic_acid')],'interpretation':'Delta E is a frozen-geometry vertical electronic contrast between analyst-positioned proton microstates. It is not an optimized energy, pKa, proton-transfer barrier, free energy, rate, or 10mer/12mer comparison. A converged result removes a real native-QM execution dependency and exposes the magnitude/direction of this precise chemical assumption; it does not qualify an enzyme.'}
with (HERE/'qm_protonation_decision.json').open('x') as f:json.dump(manifest,f,indent=2);f.write('\n')
print(json.dumps({'formula':counts,'atoms':len(atoms),'electrons':electrons,'acceptor':acceptor,'decision_sha256':digest(HERE/'qm_protonation_decision.json')}))

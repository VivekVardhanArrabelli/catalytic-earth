"""Read two root-authorized, indexed author inputs; do not execute author code."""
from pathlib import Path
import urllib.request,datetime,json,hashlib,struct,zlib
out=Path(__file__).resolve().parent
index=Path.cwd()/'.git/catalytic-earth-runs/20261002T131112Z-protease-acceleration/integration/retained_zip_entries.json'
entries=json.loads(index.read_text())['entries']
url='https://zenodo.org/api/records/22654831/files/260909_zenodo.zip/content'
targets=['GS_complex_small.pdb','GS_complex_small_opt.com']
log=out/'qm_caps_acquisition.jsonl'
assert not log.exists(),'Do not repeat the bounded acquisition'
receipts=[]
for number,name in enumerate(targets,1):
 member='zenodo_folder/MD/Zn45_SSM/MCPB/'+name
 e=next(r for r in entries if r['name']==member)
 start=e['local_header_offset']; count=30+len(member.encode())+512+e['compressed_bytes']; end=start+count-1
 assert sum(r['reserved_response_bytes'] for r in receipts)+count<=4096
 r={'request':number,'url':url,'range_start':start,'range_end':end,'reserved_response_bytes':count,'member':e,'body_bytes':0,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'attempted'}
 try:
  request=urllib.request.Request(url,headers={'Range':f'bytes={start}-{end}','Accept-Encoding':'identity','User-Agent':'CatalyticEarth-QM-source-qualification/1.0'})
  with urllib.request.urlopen(request,timeout=45) as response:
   r['http_status']=response.status;r['headers']=dict(response.headers)
   assert response.status==206
   assert response.headers.get('Content-Range')==f'bytes {start}-{end}/2313094705'
   data=response.read(count+1);r['body_bytes']=len(data);assert len(data)==count
  (out/f'qm_caps_response_{number}.bin').write_bytes(data)
  assert data[:4]==b'PK\x03\x04'
  fields=struct.unpack('<IHHHHHIIIHH',data[:30]);nl,el=fields[-2:]
  assert data[30:30+nl].decode()==member
  content=zlib.decompress(data[30+nl+el:30+nl+el+e['compressed_bytes']],-15)
  assert len(content)==e['uncompressed_bytes']
  assert f'{zlib.crc32(content):08x}'==e['crc32']
  (out/name).write_bytes(content)
  r.update(status='success',crc32_verified=True,sha256=hashlib.sha256(content).hexdigest(),response_sha256=hashlib.sha256(data).hexdigest(),extracted_bytes=len(content))
 except Exception as exc:
  r.update(status='failed',error=repr(exc))
 finally:
  with log.open('a') as f:f.write(json.dumps(r)+'\n')
  receipts.append(r)
 print(json.dumps({k:v for k,v in r.items() if k!='headers'}))
 if r['status']!='success':raise SystemExit(1)
print(json.dumps({'response_bytes':sum(r['body_bytes'] for r in receipts),'requests':len(receipts)}))

"""One-run independent assignment and primary readout audit. No model execution."""
from pathlib import Path
import gzip,hashlib,json,statistics
import numpy as np
from biotite.structure.io import pdbx

RUN=Path(__file__).resolve().parents[1]
DATA=RUN/'retrieved'
BASE=DATA/'runtime/experiment'
REMOTE=Path('/home/ubuntu/ce-p8-20261002')
AA=dict(zip('ALA ARG ASN ASP CYS GLN GLU GLY HIS ILE LEU LYS MET PHE PRO SER THR TRP TYR VAL'.split(),'ARNDCQEGHILKMFPSTWYV'))
TARGET='ALQSSWGMMGML'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def local(p):return DATA/Path(p).relative_to(REMOTE)
def load(p):return json.loads(Path(p).read_text())
manifest=load(BASE/'candidate_manifest.json')
reported=load(BASE/'water_recovery_measurements.json')
plan=load(DATA/'package/prospective_water_constraint.json')
assert len(manifest['candidates'])==8
assert [(x['id'],x['arm'],x['rfd3_seed'],x['mpnn_seed']) for x in manifest['candidates']]==[(x['id'],x['arm'],x['rfd3_seed'],x['mpnn_seed']) for x in plan['assignments']]
source={}
for line in (DATA/'package/source_motif.pdb').read_text().splitlines():
 if line[:6] in ('ATOM  ','HETATM'):
  source[(line[21],int(line[22:26]),line[12:16].strip())]=np.array([float(line[j:j+8]) for j in (30,38,46)])
ref=np.array([source[k] for k in [('C',1,'ZN1'),('A',293,'NE2'),('A',297,'NE2')]])
refwater=source[('C',1,'O1')]
refmean=ref.mean(axis=0)
Y=ref-refmean
all_paths=set();rows=[];counts={'ES':0,'monomer':0};max_difference=0;max_anchor_difference=0
for c in manifest['candidates']:
 seq=c['enzyme_sequence'];assert len(seq)==187 and hashlib.sha256(seq.encode()).hexdigest()==c['enzyme_sha256']
 assert all(seq[i-1]==a for i,a in {36:'H',37:'E',40:'H',115:'Y',152:'E'}.items())
 for pathkey,hashkey in [('scaffold_path','scaffold_sha256'),('mpnn_output_path','mpnn_output_sha256')]:assert sha(local(c[pathkey]))==c[hashkey]
 expected={(state,0,sample) for state in ('monomer','ES') for sample in range(5)}
 assert {(a['state'],a['seed'],a['sample']) for a in c['rf3_assignments']}==expected and len(c['rf3_assignments'])==10
 for state in ('monomer','ES'):
  data=load(local(c['rf3_input_paths'][state]));expected_components=[{'seq':seq,'chain_id':'A'}]
  if state=='ES':expected_components += [{'seq':TARGET,'chain_id':'B'},{'smiles':'[Zn+2].O','chain_id':'C'}]
  assert set(data)=={'name','components'} and data['components']==expected_components and data['name']==c['id']+'_'+state
 errors=[];fiterrors=[]
 for a in c['rf3_assignments']:
  p=local(a['path']);assert p.is_file() and sha(p)==a['sha256'] and p not in all_paths
  all_paths.add(p)
  exact=f"{c['id']}_{a['state']}_seed-0_sample-{a['sample']}_model.cif"
  matches=list(local(c['rf3_output_dirs'][a['state']]).rglob(exact));assert matches==[p]
  assert a['status']=='produced_pending_measurement';counts[a['state']]+=1
  with (gzip.open(p,'rt') if str(p).endswith('.gz') else p.open()) as f:cif=pdbx.CIFFile.read(f)
  model_ids=cif.block['atom_site']['pdbx_PDB_model_num'].as_array(str);assert len(set(model_ids))==1
  atoms=pdbx.get_structure(cif,model=1,use_author_fields=False,altloc='all')
  assert np.isfinite(atoms.coord).all()
  chains={};keys=set()
  for i in range(len(atoms)):
   ch=str(atoms.chain_id[i]);r=int(atoms.res_id[i]);n=str(atoms.atom_name[i]);key=(ch,r,n)
   assert key not in keys;keys.add(key)
   entry=chains.setdefault(ch,{}).setdefault(r,{'name':str(atoms.res_name[i]),'atoms':{}})
   assert entry['name']==str(atoms.res_name[i]);entry['atoms'][n]=np.asarray(atoms.coord[i],dtype=float)
  sequences={ch:''.join(AA.get(rs[r]['name'],'?') for r in sorted(rs)) for ch,rs in chains.items()}
  enzyme=[ch for ch,s in sequences.items() if s==seq];assert len(enzyme)==1
  ech=enzyme[0];assert sorted(chains[ech])==list(range(1,188))
  if a['state']=='monomer':assert set(chains)=={ech};continue
  peptide=[ch for ch,s in sequences.items() if s==TARGET];assert len(peptide)==1
  pch=peptide[0];assert sorted(chains[pch])==list(range(1,13))
  lig=[i for i in range(len(atoms)) if str(atoms.chain_id[i]) not in (ech,pch) and str(atoms.element[i]).upper() not in ('H','D')]
  assert sorted(str(atoms.element[i]).upper() for i in lig)==['O','ZN']
  zinc=np.asarray(atoms.coord[next(i for i in lig if str(atoms.element[i]).upper()=='ZN')],dtype=float)
  water=np.asarray(atoms.coord[next(i for i in lig if str(atoms.element[i]).upper()=='O')],dtype=float)
  pred=np.array([zinc,chains[ech][36]['atoms']['NE2'],chains[ech][40]['atoms']['NE2']]);center=pred.mean(axis=0);X=pred-center
  # Opposite covariance orientation to the frozen implementation; proper inverse map.
  U,S,Vh=np.linalg.svd(Y.T@X)
  assert S[1]>1e-6
  correction=np.diag([1.,1.,np.sign(np.linalg.det(Vh.T@U.T))])
  R=Vh.T@correction@U.T
  assert np.linalg.det(R)>0.999999999
  error=float(np.linalg.norm((water-center)@R+refmean-refwater))
  fit=float(np.sqrt(np.mean(np.sum((X@R-Y)**2,axis=1))))
  published=next(x for x in reported['candidates'] if x['id']==c['id'])['outputs'][a['sample']]
  assert published['sample']==a['sample'] and published['status']=='measured'
  max_difference=max(max_difference,abs(error-published['source_water_recovery_error_A']))
  max_anchor_difference=max(max_anchor_difference,abs(fit-published['three_anchor_fit_rmsd_A']))
  assert abs(error-published['source_water_recovery_error_A'])<1e-9
  assert abs(fit-published['three_anchor_fit_rmsd_A'])<1e-9
  errors.append(error);fiterrors.append(fit)
 rows.append({'id':c['id'],'arm':c['arm'],'rfd3_seed':c['rfd3_seed'],'enzyme_sha256':c['enzyme_sha256'],'ES_sample_errors_A':errors,'ES_anchor_fit_rmsd_A':fiterrors,'ES_median_error_A':statistics.median(errors)})
pairs=[]
for seed in range(4):
 fixed=next(x for x in rows if x['arm']=='water_fixed' and x['rfd3_seed']==seed)
 free=next(x for x in rows if x['arm']=='water_coordinate_free' and x['rfd3_seed']==seed)
 delta=fixed['ES_median_error_A']-free['ES_median_error_A']
 assert abs(delta-reported['paired_seed_results'][seed]['fixed_minus_free_A'])<1e-9
 pairs.append({'seed':seed,'fixed_median_error_A':fixed['ES_median_error_A'],'free_median_error_A':free['ES_median_error_A'],'fixed_minus_free_A':delta})
assert counts=={'ES':40,'monomer':40} and len(all_paths)==80
assert len({c['enzyme_sequence'] for c in manifest['candidates']})==8
assert all(x['complete'] and x['observed_ES']==5 and all(y['status']=='measured' for state in ('monomer','ES') for y in x['structural_context'][state]) for x in reported['candidates'])
signs=[x['fixed_minus_free_A'] for x in pairs]
decision='consistent_fixed_water_recovery_benefit' if max(signs)<0 else ('consistent_free_water_recovery_benefit' if min(signs)>0 else 'no_consistent_advantage')
assert decision==reported['decision']
result={'status':'independent_raw_output_audit_passed','model_execution':False,'sampling_changed':False,'raw_manifest_sha256':sha(BASE/'candidate_manifest.json'),'immutable_remote_measurement_sha256':sha(BASE/'water_recovery_measurements.json'),'frozen_decision_sha256':sha(DATA/'package/prospective_water_constraint.json'),'source_motif_sha256':sha(DATA/'package/source_motif.pdb'),'unique_enzyme_sequences':8,'assigned_candidates':8,'assigned_outputs':80,'verified_output_counts':counts,'all_80_CIF_hashes_match_manifest':True,'all_8_scaffold_and_8_MPNN_hashes_match_manifest':True,'all_16_unconditioned_prediction_inputs_match':True,'missing_or_ambiguous_outputs':0,'all_80_output_sequence_identities_match':True,'max_absolute_primary_discrepancy_A':max_difference,'max_absolute_anchor_fit_discrepancy_A':max_anchor_difference,'paired_seed_results':pairs,'decision':decision,'candidate_results':rows,'limitations':['Four paired design seeds are comparison units; five ES predictions share a trunk pass.','Independent recomputation is within this agent team, not external expert validation.','The reference is an author-derived hybrid motif; isolated12mer free termini differ from fused reporter/full-protein context.','No measured activity, kinetic improvement or Atlas efficacy is established.']}
(RUN/'evidence/independent_result_audit.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:result[k] for k in ['status','verified_output_counts','max_absolute_primary_discrepancy_A','max_absolute_anchor_fit_discrepancy_A','paired_seed_results','decision']},indent=2))

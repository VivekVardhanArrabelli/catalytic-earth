#!/usr/bin/env python3
"""Summarize immutable water-conditioning readouts; no model execution."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics
import sys
sys.dont_write_bytecode = True

ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument("--experiment", type=Path, required=True)
ap.add_argument("--lane", type=Path, required=True)
ap.add_argument("--source", type=Path, required=True)
ap.add_argument("--output", type=Path, required=True)
args = ap.parse_args()
base, lane = args.experiment.resolve(), args.lane.resolve()
sys.path.insert(0, str(lane))
from window_metrics import cif_atoms, distance

sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = json.loads(args.source.read_text())
measurement = base / "water_recovery_measurements.json"
data = json.loads(measurement.read_text())
manifest = json.loads((base / "candidate_manifest.json").read_text())
median = statistics.median
stats = lambda values: {"min": min(values), "median": median(values), "max": max(values)}
local = lambda p: base / p.split("/runtime/experiment/", 1)[1]
geometry_keys = list(data["candidates"][0]["outputs"][0]["geometry"])
summaries = []
all_rows = []
for candidate in data["candidates"]:
    outputs = candidate["outputs"]
    assert len(outputs) == 5 and all(r["status"] == "measured" for r in outputs)
    context = {}
    for state, rows in candidate["structural_context"].items():
        assert len(rows) == 5 and all(r["status"] == "measured" for r in rows)
        confidences = []
        for row in rows:
            cf = next(f for f in row["confidence_files"] if f["path"].endswith("_summary_confidences.json"))
            path = local(cf["path"])
            assert sha(path) == cf["sha256"]
            confidences.append(json.loads(path.read_text()))
        context[state] = {
            "all_187_CA_rmsd_to_scaffold_A": stats([r["enzyme_CA_rmsd_to_scaffold_A"] for r in rows]),
            "median_native_overall_plddt_0_to_1": median([r["overall_plddt"] for r in confidences]),
            "median_native_ptm": median([r["ptm"] for r in confidences]),
            "median_native_iptm": median([r["iptm"] for r in confidences])}
    summaries.append({"candidate_id": candidate["id"], "arm": candidate["arm"], "design_seed": candidate["rfd3_seed"],
                      "water_recovery_errors_A_sample_0_to_4": [r["source_water_recovery_error_A"] for r in outputs],
                      "frame_residuals_A_sample_0_to_4": [r["three_anchor_fit_rmsd_A"] for r in outputs],
                      "median_water_error_A": candidate["observed_median_error_A"],
                      "median_geometry": {k: median([r["geometry"][k] for r in outputs]) for k in geometry_keys},
                      "closest_amide_counts": dict(Counter(min(r["amide_register_distances_A"], key=r["amide_register_distances_A"].get) for r in outputs)),
                      "structural_context": context})
    all_rows.extend({"candidate_id": candidate["id"], **r} for r in outputs)

def atom_ref(a):
    return {k: a[k] for k in ("chain", "residue_number", "residue_name", "atom_name")}

def donor_diagnostic(path, state):
    atoms = cif_atoms(path, state)
    atom = {(a["chain"], a["residue_number"], a["atom_name"]): a for a in atoms}
    zinc = next(a for a in atoms if a["element"] == "ZN")
    specs = {"Zn_Y115_CA_A": (zinc, atom[("A", 115, "CA")]),
             "Zn_Y115_OH_A": (zinc, atom[("A", 115, "OH")]),
             "Zn_G7_O_A": (zinc, atom[("B", 7, "O")]),
             "Y115_OH_G7_O_A": (atom[("A", 115, "OH")], atom[("B", 7, "O")])}
    return {"path_relative_to_experiment": str(path.relative_to(base)), "sha256": sha(path),
            "state": state, "measurements": {k: {"value": distance(a["coordinates_angstrom"], b["coordinates_angstrom"]),
            "unit": "angstrom", "ordered_atoms": [atom_ref(a), atom_ref(b)]} for k, (a, b) in specs.items()}}

diagnostics = []
for candidate_id in ("water_fixed_seed3", "water_coordinate_free_seed3"):
    candidate = next(c for c in manifest["candidates"] if c["id"] == candidate_id)
    records = [donor_diagnostic(local(candidate["scaffold_path"]), "RFD3_scaffold")]
    for row in next(c for c in data["candidates"] if c["id"] == candidate_id)["outputs"]:
        path = local(row["path"])
        assert sha(path) == row["sha256"]
        records.append({"sample": row["sample"], **donor_diagnostic(path, "RF3_ES")})
    diagnostics.append({"candidate_id": candidate_id, "records": records})

extrema = {}
for key in geometry_keys:
    lo, hi = min(all_rows, key=lambda r: r["geometry"][key]), max(all_rows, key=lambda r: r["geometry"][key])
    extrema[key] = {**stats([r["geometry"][key] for r in all_rows]),
                    "min_assignment": [lo["candidate_id"], lo["sample"]], "max_assignment": [hi["candidate_id"], hi["sample"]],
                    "source_reference": source["metrics"][key]["value"]}

report = {
    "kind": "post_run_mechanistic_context_without_new_thresholds_or_exclusions",
    "raw_measurements": {"path_relative_to_experiment": "water_recovery_measurements.json", "sha256": sha(measurement)},
    "source_geometry": {"filename": args.source.name, "sha256": sha(args.source)},
    "readout_operations": {"path_relative_to_lane": "window_metrics.py", "sha256": sha(lane / "window_metrics.py")},
    "assigned_and_observed": {"candidates": 8, "ES": 40, "monomer": 40},
    "frozen_primary_decision": data["decision"], "paired_water_results": data["paired_seed_results"],
    "candidate_summaries": summaries, "all_ES_geometry_ranges": extrema,
    "all_ES_closest_amide_counts": dict(Counter(min(r["amide_register_distances_A"], key=r["amide_register_distances_A"].get) for r in all_rows)),
    "post_hoc_donor_localization": diagnostics,
    "observations": [
        "The frozen primary has mixed signs across four design-seed pairs. Five samples share each RF3 trunk and are not independent design replicates.",
        "Low source-water error does not imply recovery of the complete catalytic arrangement. water_fixed_seed3 retains the closest scaffold fold and water/base placement, but its donor-to-intended-carbonyl distance is 7.137-13.557 A versus source 2.574 A.",
        "Both seed3 RFD3 scaffolds retain the imposed donor/carbonyl arrangement. Their independent RF3 predictions move both donor backbone/sidechain and substrate; this is not an omitted initial donor constraint or peptide displacement alone.",
        "Several candidates strongly disagree with their generated scaffold. Free seed2 also distorts the three-anchor frame: residuals 0.071,2.573,5.116,10.869,9.218 A. These remain in the frozen primary; they prevent attributing that pair's contrast solely to water placement in an otherwise conserved site.",
        "Zn-water proximity often survives while glutamate coordination, general-base proximity, donor placement or the intended peptide register does not. The nearest amide is G7-M8 in 10/40 outputs; proximity is not a predicted cleavage assignment.",
        "Extreme values remain visible, including G7C-M8N 0.896 A in fixed seed2/sample4 and Zn-water 1.146 A at its recorded assignment. A water-carbonyl approach angle at a large water-carbonyl distance is geometric context, not an attack-ready state.",
        "Native confidence is context only. Fixed seed3 median complex overall pLDDT is 0.8015 and ipTM is 0.8774 despite loss of its intended donor/substrate arrangement."
    ],
    "next_action": {
        "decision": "Stop expanding the water-coordinate ablation; preserve the mixed result. The next independently authorized comparison should hold the existing water_fixed_seed3 scaffold fixed and compare native LigandMPNN atomize_side_chains=False versus True with equal frozen sequence-design seeds.",
        "named_dependency": "Sequence-supported recovery of the whole donor/base/substrate arrangement on a scaffold whose global fold and water can already recover.",
        "execution_scope": "Keep the same backbone, full target, five catalytic identities, Zn2+/neutral water, sampling settings and fixed residue identities. The native True arm adds fixed enzyme AND fixed substrate sidechains as atom context; it is not a Tyr-only intervention. Freeze a small paired sequence set and the unconditioned RF3 joint readout before execution. This is an exploratory mechanism test on a post hoc selected scaffold, not a continuation of the confirmatory four-pair comparison.",
        "decision_value": "A sequence that recovers donor/substrate geometry while retaining fold and other site contacts would demonstrate a capability absent in the current eight designs and justify further optimization. Repeated loss on a bounded assigned set would close this backbone for now and motivate changing motif embedding; it would not prove the backbone universally undesignable.",
        "why_not_more_same_sampling": "The completed run explicitly used atomize_side_chains=False. Retained native source shows this hides all protein sidechains during sequence design, while True reveals only fixed-residue sidechains and adds them to atom context. This provides a concrete paired intervention beyond random new sequences or more RF3 draws. It is a possible contributor, not a proven cause of failed recovery; the source scaffold's clamped contacts were never independent physical validation.",
        "current_authorization": "Recommendation only. No new sequence design, prediction, paid action or QM was performed by this review. Stopping now is preferable if a prospective full-site readout cannot be frozen or additional execution is not authorized."
    },
    "next_action_source_evidence": {
        "foundry_commit": "0932f1cb165ae7d413c11b1a7acc04ee31758817",
        "completed_seed3_config": {"path_relative_to_experiment": "candidates/water_fixed_seed3/mpnn_config.json", "sha256": sha(base / "candidates/water_fixed_seed3/mpnn_config.json"), "atomize_side_chains": False},
        "native_sidechain_mask": {"path_relative_to_foundry": "models/mpnn/src/mpnn/model/mpnn.py", "sha256": "1aeae0716775140f8189b3734d05dab369c2a0328ae74d669b031f9c861b06b2", "lines": [2436, 2468]},
        "native_atom_context": {"path_relative_to_foundry": "models/mpnn/src/mpnn/model/layers/graph_embeddings.py", "sha256": "5b82a1277ce141f6166060231c95e8e41849fd47e34b853c604975011e04ffd5", "lines": [2300, 2336]},
        "qualification": "Source inspection establishes the option's documented implementation, not successful execution of a future True arm or causality in this experiment."
    },
    "public_readme_review": {"path_relative_to_lane": "results_20261002/README.md", "sha256_at_review": sha(lane / "results_20261002/README.md"), "result": "Geometry values, source identities, unchanged primary and stage-localization language agree with the retained measurements. The text correctly does not distinguish sequence incompatibility from prediction error, and correctly states that a future True context arm exposes both enzyme and substrate fixed sidechains. No scientific correction requested."},
    "claim_boundary": "Computational geometry only. The source is an author-derived hybrid motif, not a measured TDPn3 water position. No productive-state, catalytic activity, barrier, cleavage specificity or Atlas efficacy claim. No new primary pass threshold, exclusions, inferential statistics or candidate replacement."
}
args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
print(json.dumps({"output": str(args.output), "sha256": sha(args.output), "decision": data["decision"]}))

#!/usr/bin/env python3
"""Measure the retained source motif with the frozen experiment's operations."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True

ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument("--lane", type=Path, required=True)
ap.add_argument("--output", type=Path, required=True)
args = ap.parse_args()
lane = args.lane.resolve()
sys.path.insert(0, str(lane))
from window_metrics import angle, distance

sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
plan = json.loads((lane / "prospective_water_constraint.json").read_text())
source = lane / "source_motif.pdb"
target = lane / "inputs/ALQSSWGMMGML78_Zn2plus.pdb"

def read_pdb(path):
    atoms = {}
    for line in path.read_text().splitlines():
        if line[:6] not in ("ATOM  ", "HETATM"):
            continue
        key = (line[21], int(line[22:26]), line[12:16].strip())
        assert key not in atoms
        atoms[key] = {"chain": key[0], "residue_number": key[1],
                      "residue_name": line[17:20].strip(), "atom_name": key[2],
                      "coordinates": [float(line[i:i+8]) for i in (30, 38, 46)]}
    return atoms

atoms, adapted = read_pdb(source), read_pdb(target)
mapping, position = {}, 0
for part in plan["shared_input"]["contig"].split(","):
    if part.startswith("/0"):
        break
    if part.isdigit():
        position += int(part)
    else:
        first, last = (int(v) for v in part[1:].split("-"))
        for original in range(first, last+1):
            position += 1
            mapping[original] = position
assert position == 187
roles = {"metal_histidine_1": (293, 36, "HIS"), "general_base": (294, 37, "GLU"),
         "metal_histidine_2": (297, 40, "HIS"), "oxyanion_donor": (377, 115, "TYR"),
         "metal_glutamate": (316, 152, "GLU")}
for original, mapped, name in roles.values():
    assert mapping[original] == mapped and atoms[("A", original, "CA")]["residue_name"] == name
inherited = [("B", p, n) for p in (7, 8) for n in ("N", "CA", "C", "O")]
assert all(atoms[k]["coordinates"] == adapted[k]["coordinates"] for k in inherited)
assert adapted[("B", 7, "CA")]["residue_name"] == "GLY"
assert adapted[("B", 8, "CA")]["residue_name"] == "MET"

zn, water = ("C", 1, "ZN1"), ("C", 1, "O1")
carbon, oxygen, nitrogen = ("B", 7, "C"), ("B", 7, "O"), ("B", 8, "N")
specs = {
    "Zn_H36_NE2_A": (zn, ("A", 293, "NE2")),
    "Zn_H40_NE2_A": (zn, ("A", 297, "NE2")),
    "Zn_water_A": (zn, water), "Zn_G7_O_A": (zn, oxygen),
    "water_G7_C_A": (water, carbon),
    "water_G7_C_G7_O_degrees": (water, carbon, oxygen),
    "Y115_OH_G7_O_A": (("A", 377, "OH"), oxygen),
    "Y115_CZ_OH_G7_O_degrees": (("A", 377, "CZ"), ("A", 377, "OH"), oxygen),
    "G7_C_M8_N_A": (carbon, nitrogen)}

def ref(key):
    return {"model_state": "author_hybrid_source_motif", **{k: v for k, v in atoms[key].items() if k != "coordinates"}}

def measure(keys):
    return {"value": (distance if len(keys) == 2 else angle)(*(atoms[k]["coordinates"] for k in keys)),
            "unit": "angstrom" if len(keys) == 2 else "degree",
            "ordered_atoms": [ref(k) for k in keys]}

metrics = {name: measure(keys) for name, keys in specs.items()}
for name, keys in {"Zn_E152_min_A": [(zn, ("A", 316, o)) for o in ("OE1", "OE2")],
                   "E37_water_min_A": [(("A", 294, o), water) for o in ("OE1", "OE2")]}.items():
    options = [measure(k) for k in keys]
    metrics[name] = {**min(options, key=lambda v: v["value"]), "operation": "minimum", "alternatives": options}
register = [{"source_amide": label, **measure((zn, ("B", pos, "O")))}
            for pos, label in ((6, "V6-N7"), (7, "N7-F8"))]
report = {
    "source": {"path_relative_to_lane": "source_motif.pdb", "sha256": sha(source)},
    "prospective_input": {"path_relative_to_lane": "inputs/ALQSSWGMMGML78_Zn2plus.pdb", "sha256": sha(target)},
    "readout_operations": {"path_relative_to_lane": "window_metrics.py", "sha256": sha(lane / "window_metrics.py"), "functions": ["distance", "angle"]},
    "frozen_plan_sha256": sha(lane / "prospective_water_constraint.json"),
    "role_mapping": [{"role": role, "source_chain": "A", "source_residue_number": old,
                      "source_residue_name": name, "candidate_chain": "A", "candidate_residue_number": new}
                     for role, (old, new, name) in roles.items()],
    "source_peptide": "Cropped source coordinates contain V6-N7-F8, not the target sequence. Exactly eight B7/B8 N/CA/C/O coordinates are inherited in prospective G7/M8; metric keys use the frozen target readout labels, while ordered_atoms preserve actual source identities.",
    "metrics": metrics,
    "source_available_amide_register_distances": register,
    "source_closest_available_amide": min(register, key=lambda row: row["value"])["source_amide"],
    "full_target_register_reference": "Unavailable: most prospective target coordinates are zero placeholders and must not be measured. Source B8 lacks its following residue in the crop, so B8 carbonyl is not included as a complete source amide.",
    "interpretation": "Reference geometry, not productive thresholds or physical optimality. Hybrid source motif is not an experimental structure of a new candidate or TDPn3. No filtering or prediction performed."
}
args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
print(json.dumps({"metrics": {k: v["value"] for k, v in metrics.items()}, "register": register}, indent=2))

from pathlib import Path
import json,hashlib,statistics,csv,sys,importlib.util,math,gzip,io
from biotite.structure.io import pdbx
repo=Path.cwd();run=repo/'.git/catalytic-earth-runs/20261002T182054Z-protease-water-execution';exp=run/'retrieved/runtime/experiment';out=run/'models';pkg=repo/'tools/research_lanes/protease_retargeting/water_conditioning'
sys.path.insert(0,str(pkg));spec=importlib.util.spec_from_file_location('frozen_measurement',pkg/'measure_water_recovery.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def native_rows(path,_):
 text=gzip.decompress(path.read_bytes()).decode() if path.suffix=='.gz' else path.read_text();site=pdbx.CIFFile.read(io.StringIO(text)).block['atom_site'];cols={k:site[k].as_array(str) for k in site}
 assert set(cols['pdbx_PDB_model_num'])=={'1'}
 result=[]
 for i in range(len(cols['Cartn_x'])):
  get=lambda k:str(cols[k][i])
  ins=get('pdbx_PDB_ins_code');assert get('label_alt_id') in ('.','?')
  result.append({'chain':get('auth_asym_id'),'residue_number':int(get('auth_seq_id')),'insertion_code':'' if ins in ('.','?') else ins,
   'residue_name':get('auth_comp_id'),'atom_name':get('auth_atom_id'),'element':get('type_symbol').upper(),
   'coordinates_angstrom':[float(get(k)) for k in ('Cartn_x','Cartn_y','Cartn_z')],'occupancy':float(get('occupancy'))})
 return result
# Use the native CIF reader without dropping any atom. Frozen metric functions stay intact.
m.cif_atoms=native_rows
manifest=json.loads((exp/'candidate_manifest.json').read_text());measure=json.loads((exp/'water_recovery_measurements.json').read_text());byid={c['id']:c for c in measure['candidates']};assert len(manifest['candidates'])==8
source=pkg/'source_motif.pdb';anchors,water=m.reference(source);sa={}
for line in source.read_text().splitlines():
 if line[:6] in ('ATOM  ','HETATM'):sa[line[21],int(line[22:26]),line[12:16].strip()]=[float(line[i:i+8]) for i in (30,38,46)]
a=lambda chain,num,atom:sa[chain,num,atom];z=a('C',1,'ZN1');w=a('C',1,'O1');g=a('B',7,'C');go=a('B',7,'O');mi=a('B',8,'N');d=m.distance;ang=m.angle
sg={'Zn_H36_NE2_A':d(z,a('A',293,'NE2')),'Zn_H40_NE2_A':d(z,a('A',297,'NE2')),'Zn_E152_min_A':min(d(z,a('A',316,k)) for k in ('OE1','OE2')),'E37_water_min_A':min(d(w,a('A',294,k)) for k in ('OE1','OE2')),'Zn_water_A':d(z,w),'Zn_G7_O_A':d(z,go),'water_G7_C_A':d(w,g),'water_G7_C_G7_O_degrees':ang(w,g,go),'Y115_OH_G7_O_A':d(a('A',377,'OH'),go),'Y115_CZ_OH_G7_O_degrees':ang(a('A',377,'CZ'),a('A',377,'OH'),go),'G7_C_M8_N_A':d(g,mi)}
r={'status':'completed_all_assigned_scaffold_and_mpnn_stage_measurements','model_execution':False,'method':'Unmodified frozen observe() geometry and identity functions called with actual sequence extracted from each stage chain A. Native Biotite CIF reader preserves every written atom, including unresolved terminal OXT; no atom/candidate exclusion. All required measured coordinates finite. All five assigned RF3 ES records used per candidate.',
 'measurement_source_sha256':sha(pkg/'measure_water_recovery.py'),'adapter_sha256':sha(Path(__file__)),'candidate_manifest_sha256':sha(exp/'candidate_manifest.json'),'rf3_measurement_sha256':sha(exp/'water_recovery_measurements.json'),
 'source_reference':{'path':str(source),'sha256':sha(source),'role_map':{'H36':293,'E37':294,'H40':297,'Y115':377,'E152':316},'geometry':sg},'candidates':[]}
rows=[{'candidate':'source_input','arm':'both','rfd3_seed':'','stage':'SOURCE','sample':'','source_water_recovery_error_A':0.,'three_anchor_fit_rmsd_A':0.,**sg}];pooled={'RFD3':[],'LigandMPNN':[],'RF3':[]}
for c in manifest['candidates']:
 cid=c['id'];folder=exp/'candidates'/cid;stages={};maps={}
 for stage,path in [('RFD3',folder/'rfd3/rfd3_input_des_0_model_0.cif.gz'),('LigandMPNN',folder/'mpnn'/f'{cid}_b0_d0.cif')]:
  atoms=native_rows(path,'');res={};am={}
  for x in atoms:
   k=(x['chain'],x['residue_number'],x['atom_name']);assert k not in am;am[k]=x['coordinates_angstrom'];rs=res.setdefault(x['chain'],{});num=x['residue_number'];assert num not in rs or rs[num]==x['residue_name'];rs[num]=x['residue_name']
  assert sorted(res['A'])==list(range(1,188)) and sorted(res['B'])==list(range(1,13));seq=''.join(m.AA[res['A'][i]] for i in range(1,188));assert ''.join(m.AA[res['B'][i]] for i in range(1,13))==m.PEPTIDE
  if stage=='LigandMPNN':assert seq==c['enzyme_sequence']
  rec=m.observe(path,seq,anchors,water);assert rec['status']=='measured',rec;assert all(math.isfinite(v) for v in rec['geometry'].values())
  rec['actual_stage_sequence_A']=seq;rec['actual_stage_sequence_A_sha256']=hashlib.sha256(seq.encode()).hexdigest();rec['unresolved_written_atoms']=[{'chain':x['chain'],'residue':x['residue_number'],'atom':x['atom_name'],'occupancy':x['occupancy']} for x in atoms if not all(math.isfinite(v) for v in x['coordinates_angstrom'])]
  stages[stage]=rec;maps[stage]=am;pooled[stage].append(rec);rows.append({'candidate':cid,'arm':c['arm'],'rfd3_seed':c['rfd3_seed'],'stage':stage,'sample':'',**{k:rec[k] for k in ('source_water_recovery_error_A','three_anchor_fit_rmsd_A')},**rec['geometry']})
 rf3=byid[cid]['outputs'];assert len(rf3)==5 and all(x['status']=='measured' for x in rf3)
 for x in rf3:
  assert sha(exp/Path(x['path']).relative_to('/home/ubuntu/ce-p8-20261002/runtime/experiment'))==x['sha256']
  rows.append({'candidate':cid,'arm':c['arm'],'rfd3_seed':c['rfd3_seed'],'stage':'RF3_ES','sample':x['sample'],**{k:x[k] for k in ('source_water_recovery_error_A','three_anchor_fit_rmsd_A')},**x['geometry']});pooled['RF3'].append(x)
 common=[k for k in maps['RFD3'] if (k[0]=='A' and k[1] in (36,37,40,115,152)) or (k[0]=='B' and k[1] in (7,8) and k[2] in ('N','CA','C','O')) or k[0]=='C'];assert all(k in maps['LigandMPNN'] for k in common)
 delta=max(d(maps['RFD3'][k],maps['LigandMPNN'][k]) for k in common)
 stats={key:{'min':min(x['geometry'][key] for x in rf3),'median':statistics.median(x['geometry'][key] for x in rf3),'max':max(x['geometry'][key] for x in rf3)} for key in sg}
 r['candidates'].append({'id':cid,'arm':c['arm'],'rfd3_seed':c['rfd3_seed'],'stages':stages,'RFD3_to_MPNN_retained_motif_atom_count':len(common),'RFD3_to_MPNN_retained_motif_max_displacement_A':delta,'RF3_all_five_geometry':stats})
r['pooled_stage_ranges']={stage:{k:{'min':min(x['geometry'][k] for x in vals),'max':max(x['geometry'][k] for x in vals)} for k in sg} for stage,vals in pooled.items()}
r['claim_boundary']='Descriptive stage localization of computational outputs; no new thresholds, exclusion, activity evidence or Atlas advantage. Primary mixed comparison unchanged. RFD3 sequence and LigandMPNN sequence are separately identified; MPNN does not relax coordinates.'
cp=out/'all8_stage_geometry.csv'
with cp.open('x',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
r['table']={'path':str(cp),'sha256':sha(cp),'rows':len(rows)};jp=out/'all8_stage_geometry.json';jp.open('x').write(json.dumps(r,indent=2)+'\n')
print(json.dumps({'receipt_sha256':sha(jp),'table_sha256':sha(cp),'rows':len(rows),'retained_max_displacement_A':max(x['RFD3_to_MPNN_retained_motif_max_displacement_A'] for x in r['candidates']),'source':sg,'stage_ranges':r['pooled_stage_ranges']},indent=2))

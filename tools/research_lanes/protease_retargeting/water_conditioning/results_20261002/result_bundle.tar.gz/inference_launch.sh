#!/usr/bin/env bash
set -uo pipefail
export CE_P8_RUNTIME=/home/ubuntu/ce-p8-20261002/runtime
export CE_P8_PACKAGE=/home/ubuntu/ce-p8-20261002/package
export PATH="$CE_P8_RUNTIME/venv/bin:$PATH"
unset LOCAL_MSA_DIRS
test "$(cat /home/ubuntu/ce-p8-20261002/bootstrap_exit_code.txt)" = 0 || exit 1
date -u +%FT%TZ > /home/ubuntu/ce-p8-20261002/inference_started.txt
python "$CE_P8_PACKAGE/run_prospective_designs.py" \
  --input-dir "$CE_P8_PACKAGE/inputs" \
  --foundry-root "$CE_P8_RUNTIME/foundry" \
  --out-dir "$CE_P8_RUNTIME/experiment" \
  --checkpoint-dir "$CE_P8_RUNTIME/checkpoints" \
  --checkpoint-receipt "$CE_P8_RUNTIME/checkpoint_receipts.json" \
  --native-pair-receipt "$CE_P8_RUNTIME/native_pair_verified.json" \
  --max-seconds 5400 --execute
CE_P8_RUN_STATUS=$?
echo "$CE_P8_RUN_STATUS" > /home/ubuntu/ce-p8-20261002/inference_exit_code.txt
date -u +%FT%TZ > /home/ubuntu/ce-p8-20261002/inference_finished.txt
exit "$CE_P8_RUN_STATUS"

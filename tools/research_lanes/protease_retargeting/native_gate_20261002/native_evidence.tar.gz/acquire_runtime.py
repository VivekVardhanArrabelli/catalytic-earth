"""Bounded official runtime acquisition; no model weights or torch downloads."""
from pathlib import Path
import concurrent.futures, hashlib, io, json, tarfile, threading, urllib.request, zipfile

ROOT = Path(__file__).resolve().parent
CAP = 800 * 1024**2
report = json.loads((ROOT / 'dependency_resolver.json').read_text())
wheels = ROOT / 'wheels'
wheels.mkdir(exist_ok=False)
lock = threading.Lock()
traffic = 0
receipts = []

def fetch(item):
    global traffic
    meta = item['metadata']
    assert meta['name'].lower() not in ('torch', 'nvidia', 'cuda')
    url = item['download_info']['url']
    assert url.startswith('https://files.pythonhosted.org/')
    dest = wheels / url.rsplit('/', 1)[-1]
    h = hashlib.sha256()
    n = 0
    with urllib.request.urlopen(url, timeout=60) as response, dest.open('xb') as out:
        headers = dict(response.headers)
        while block := response.read(1024 * 1024):
            with lock:
                traffic += len(block)
                assert traffic < 250 * 1024**2, 'Runtime package compressed-byte cap reached'
            out.write(block); h.update(block); n += len(block)
    expected = item['download_info']['archive_info']['hashes']['sha256']
    assert h.hexdigest() == expected
    receipt = {'name': meta['name'], 'version': meta['version'], 'url': url, 'bytes': n,
               'sha256': h.hexdigest(), 'headers': headers, 'file': dest.name}
    with lock:
        receipts.append(receipt)
        (ROOT / 'runtime_package_receipts.json').write_text(json.dumps(receipts, indent=2)+'\n')
    return n

with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
    list(pool.map(fetch, report['install']))

# Extract only upstream packages/configs from the immutable official archive.
url = 'https://codeload.github.com/RosettaCommons/foundry/tar.gz/0932f1cb165ae7d413c11b1a7acc04ee31758817'
source = ROOT / 'foundry'
source.mkdir(exist_ok=False)
class Meter:
    def __init__(self, response): self.response=response; self.n=0; self.h=hashlib.sha256()
    def read(self, size=-1):
        block=self.response.read(size); self.n+=len(block); self.h.update(block)
        assert self.n < 200*1024**2, 'Official runtime source compressed-byte cap reached'
        return block
extracted=[]
with urllib.request.urlopen(url, timeout=60) as response:
    meter=Meter(response)
    with tarfile.open(fileobj=meter, mode='r|gz') as archive:
        for member in archive:
            bits=Path(member.name).parts[1:]
            if not bits or not member.isfile(): continue
            keep=(bits[0]=='src' or (len(bits)>2 and bits[0]=='models' and bits[2] in ('src','configs')) or
                  (len(bits)==1 and bits[0] in ('pyproject.toml','README.md','LICENSE.md','.project-root')))
            if not keep: continue
            dest=source.joinpath(*bits)
            assert dest.resolve().is_relative_to(source.resolve())
            dest.parent.mkdir(parents=True,exist_ok=True)
            data=archive.extractfile(member).read()
            dest.write_bytes(data)
            extracted.append({'path':'/'.join(bits),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    while meter.read(1024*1024): pass
    (ROOT/'runtime_source_receipt.json').write_text(json.dumps({'url':url,'body_bytes':meter.n,'sha256':meter.h.hexdigest(),'extracted_files':extracted},indent=2)+'\n')

expanded=0
for p in wheels.iterdir():
    if p.suffix=='.whl':
        with zipfile.ZipFile(p) as z: expanded+=sum(i.file_size for i in z.infolist())
    else:
        with tarfile.open(p) as t: expanded+=sum(i.size for i in t if i.isfile())
existing=sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())
estimate={'retained_before_install_bytes':existing,'package_archive_body_bytes':traffic,'package_expanded_bytes':expanded,
          'conservative_install_peak_estimate_bytes':existing+expanded*1.2,'cap_bytes':CAP,
          'prior_pip_resolver_traffic':'Not exactly metered; resolver logs retain advertised wheel sizes. Do not treat these receipts as all setup traffic.'}
(ROOT/'runtime_size_estimate.json').write_text(json.dumps(estimate,indent=2)+'\n')
assert estimate['conservative_install_peak_estimate_bytes']<CAP, 'Stop: installation would exceed bounded disk allocation'
print(json.dumps(estimate,indent=2))

#!/usr/bin/env python3
"""Bounded checks of the actual measurement module, with no biological inference."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import numpy as np

root=Path(__file__).resolve().parent
run=root.parent
package=run/'experiment/package'
sys.path.insert(0,str(package))
spec=importlib.util.spec_from_file_location('measure_water_recovery',package/'measure_water_recovery.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'status':'failed','measurement_source':str(spec.origin),'measurement_sha256':sha(Path(spec.origin)),
        'test_driver_sha256':sha(Path(__file__)),'model_execution':False,'tests':[]}
pdb=root/'corrected_inputs/ALQSSWGMMGML78_Zn2plus.pdb'
anchors,water=m.reference(pdb)
anchors=np.asarray(anchors);water=np.asarray(water)
axis=np.array([1.,2.,3.]);axis/=np.linalg.norm(axis);theta=0.83
x,y,z=axis
cross=np.array([[0,-z,y],[z,0,-x],[-y,x,0.]])
rot=np.eye(3)*np.cos(theta)+(1-np.cos(theta))*np.outer(axis,axis)+np.sin(theta)*cross
translation=np.array([13.4,-7.1,20.5])
for label,shift,expected in [('rigid_rotation_translation',np.zeros(3),0.),('water_displaced_1A',np.array([1.,0,0]),1.)]:
 result=m.water_recovery(anchors@rot+translation,(water+shift)@rot+translation,anchors,water)
 assert abs(result['source_water_recovery_error_A']-expected)<1e-10, result
 assert result['three_anchor_fit_rmsd_A']<1e-10,result
 report['tests'].append({'name':label,'status':'passed',**result})
for label,points in [('collinear_anchors',[[0,0,0],[1,0,0],[2,0,0]]),('coincident_anchors',[[1,1,1]]*3)]:
 try:m.fit_transform(points,points)
 except ValueError as error:report['tests'].append({'name':label,'status':'rejected_as_required','error':str(error)})
 else:raise AssertionError('Degenerate anchor frame accepted')
old=run.parent/'20261002T153616Z-problem8-continuation/retrieved/bundle/output/seed-0/predictions/TDPn3_ES_window_12mer'
slots=m.assigned_samples(old,'TDPn3_ES_window_12mer')
assert len(slots)==5 and all(len(s['matches'])==1 for s in slots), slots
aggregate=old/'TDPn3_ES_window_12mer_model.cif'
assert aggregate.exists() and all(aggregate not in s['matches'] for s in slots)
report['tests'].append({'name':'actual_prior_output_slots_exclude_aggregate','status':'passed','assigned_samples':5,
 'matched_files':[str(s['matches'][0]) for s in slots],'excluded_aggregate':str(aggregate)})
# No candidate records must still expose every prospective denominator.
empty=root/'measurement_empty_manifest.json';empty.write_text('{"candidates": []}\n')
output=root/'measurement_empty_result.json'
subprocess.run([sys.executable,str(package/'measure_water_recovery.py'),'--manifest',str(empty),
 '--decision',str(run/'experiment/prospective_water_constraint.json'),'--source-pdb',str(pdb),'--output',str(output)],check=True)
result=json.loads(output.read_text())
assert result['assigned_candidates']==8 and result['assigned_ES_outputs']==40 and result['assigned_monomer_outputs']==40
assert len(result['candidates'])==8 and all(r['assigned_ES']==5 and r['observed_ES']==0 and not r['complete'] and len(r['outputs'])==5 for r in result['candidates'])
assert result['decision']=='incomplete_comparison' and len(result['paired_seed_results'])==4 and not any(p['complete'] for p in result['paired_seed_results'])
report['tests'].append({'name':'empty_manifest_preserves_all_assignments','status':'passed',
 'assigned_candidates':8,'assigned_ES_outputs':40,'assigned_monomer_outputs':40,'decision':result['decision'],
 'result_sha256':sha(output)})
report['status']='passed_bounded_measurement_checks'
report['qualification']='Tests establish coordinate-transform arithmetic and assigned-output accounting, not biological function or scientific usefulness.'
(root/'measurement_review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'tests':len(report['tests'])}))

#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/ubuntu/ra95-fold-20260923
RFD2_ROOT="$ROOT/RFdiffusion2"
mkdir -p "$ROOT/logs"
exec > >(tee -a "$ROOT/logs/setup.log") 2>&1
date -u +%FT%TZ
nvidia-smi
python3 - <<'INNER'
import shutil
free=shutil.disk_usage('/home/ubuntu').free
assert free >= 100*1024**3, free
print('remote_free_bytes',free)
INNER
if ! command -v apptainer >/dev/null; then
  sudo add-apt-repository -y ppa:apptainer/ppa
  sudo apt-get update -qq
  sudo apt-get install -y apptainer
fi
apptainer version
if [[ -e "$RFD2_ROOT" ]]; then
  test "$(git -C "$RFD2_ROOT" rev-parse HEAD)" = d365cbf4db3958814a9f8e4f6f94fa309dfebc2b
else
  git init "$RFD2_ROOT"
  git -C "$RFD2_ROOT" remote add origin https://github.com/RosettaCommons/RFdiffusion2.git
  git -C "$RFD2_ROOT" fetch --depth 1 origin d365cbf4db3958814a9f8e4f6f94fa309dfebc2b
  git -C "$RFD2_ROOT" checkout --detach FETCH_HEAD
fi
git -C "$RFD2_ROOT" diff --quiet HEAD -- rf_diffusion fused_mpnn lib/chai setup.py
mkdir -p "$RFD2_ROOT/rf_diffusion/exec" "$RFD2_ROOT/rf_diffusion/third_party_model_weights/ligand_mpnn"
python3 - <<'INNER'
import concurrent.futures,hashlib,json,pathlib,time,urllib.request
root=pathlib.Path('/home/ubuntu/ra95-fold-20260923')
repo=root/'RFdiffusion2'
base='https://files.ipd.uw.edu/pub/rfdiffusion2/'
assets=[('sifs/mlfold.sif','rf_diffusion/exec/mlfold.sif',6245179392),('sifs/chai.sif','rf_diffusion/exec/chai.sif',8396939264),('third_party_model_weights/ligand_mpnn/s25_r010_t300_p.pt','rf_diffusion/third_party_model_weights/ligand_mpnn/s25_r010_t300_p.pt',31610531),('third_party_model_weights/ligand_mpnn/s_300756.pt','rf_diffusion/third_party_model_weights/ligand_mpnn/s_300756.pt',43061623)]
def fetch(item):
 rel,dest,expected=item
 url=base+rel
 p=repo/dest
 if p.exists(): raise RuntimeError('fresh asset already exists: '+str(p))
 tmp=p.with_suffix(p.suffix+'.part')
 digest=hashlib.sha256(); size=0
 print('Downloading',rel,flush=True)
 with urllib.request.urlopen(url,timeout=90) as response,tmp.open('wb') as out:
  while True:
   chunk=response.read(8*1024*1024)
   if not chunk: break
   out.write(chunk);digest.update(chunk);size+=len(chunk)
 assert size==expected,(rel,size,expected)
 tmp.rename(p)
 row={'url':url,'path':dest,'bytes':size,'sha256':digest.hexdigest()}
 print(json.dumps(row),flush=True)
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: rows=list(pool.map(fetch,assets))
(root/'logs/runtime-assets.json').write_text(json.dumps(rows,indent=2)+'\n')
INNER
export PYTHONPATH="$RFD2_ROOT"
cd "$RFD2_ROOT"
apptainer exec --nv --bind "$ROOT:$ROOT" rf_diffusion/exec/mlfold.sif python -c 'import torch; print("mpnn", torch.__version__, torch.cuda.is_available(), torch.cuda.get_device_name(0))'
apptainer exec --nv --bind "$ROOT:$ROOT" rf_diffusion/exec/chai.sif python -c 'import torch; print("chai", torch.__version__, torch.cuda.is_available(), torch.cuda.get_device_name(0))'
date -u +%FT%TZ
printf '%s\n' setup_complete > "$ROOT/logs/setup-complete"

#!/usr/bin/env python3
import datetime,hashlib,json,pathlib,subprocess,tarfile
root=pathlib.Path('/home/ubuntu/ra95-fold-20260923')
repo=root/'RFdiffusion2'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
identity={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'revision':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'tracked_diff':subprocess.check_output(['git','-C',str(repo),'diff','HEAD'],text=True),'git_status_tracked':subprocess.check_output(['git','-C',str(repo),'status','--porcelain','--untracked-files=no'],text=True),'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.total,driver_version','--format=csv,noheader'],text=True).strip()}
(root/'logs/source-and-gpu.json').write_text(json.dumps(identity,indent=2)+'\n')
assets=[]; hashed={}
cache=root/'chai_downloads'
if cache.exists():
 for p in sorted(cache.rglob('*')):
  if not p.is_file():continue
  real=p.resolve()
  if real not in hashed:hashed[real]=sha(p)
  row={'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashed[real]}
  if p.is_symlink():row['symlink_target']=str(p.readlink())
  if p.name in ['main'] and p.stat().st_size<1000:row['content']=p.read_text()
  assets.append(row)
(root/'logs/chai-assets.json').write_text(json.dumps(assets,indent=2)+'\n')
files=sorted([p for folder in ['logs','output'] for p in (root/folder).rglob('*') if p.is_file()]+[root/'setup_remote.sh',root/'run_models.sh',root/'preserve_remote.py',root/'launch_bounded.sh'])
rows=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]
manifest=root/'MANIFEST.json';manifest.write_text(json.dumps(rows,indent=2)+'\n')
archive=root/'continuation-bundle.tgz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files+[manifest]:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
receipt={'bundle':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(files)+1}
(root/'bundle-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))

#!/usr/bin/env bash
set -u
ROOT=/home/ubuntu/ra95-fold-20260923
remaining=$(python3 - <<'BOUND'
import datetime
end=datetime.datetime.fromisoformat('2026-09-23T12:12:56.589784+00:00')
print(max(0,int((end-datetime.datetime.now(datetime.timezone.utc)).total_seconds())-480))
BOUND
)
if [ "$remaining" -lt 600 ]; then
 printf 'insufficient_time %s seconds\n' "$remaining" > "$ROOT/logs/launcher-exit.txt"
 exit 125
fi
printf 'model_timeout_seconds %s\n' "$remaining" > "$ROOT/logs/time-bound.txt"
timeout --kill-after=30s "${remaining}s" bash "$ROOT/run_models.sh"
rc=$?
printf '%s %s\n' "$(date -u +%FT%TZ)" "$rc" > "$ROOT/logs/launcher-exit.txt"
exit "$rc"

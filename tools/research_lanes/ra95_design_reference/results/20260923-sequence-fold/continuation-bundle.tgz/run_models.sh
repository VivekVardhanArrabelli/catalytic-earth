#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/ubuntu/ra95-fold-20260923
export RFD2_ROOT="$ROOT/RFdiffusion2"
export RA95_CONT="$ROOT/output"
export PYTHONPATH="$RFD2_ROOT"
export CHAI_DOWNLOADS_DIR="$ROOT/chai_downloads"
stage=preflight
exec > >(tee "$ROOT/logs/models.log") 2>&1
trap 'rc=$?; printf "%s %s %s\n" "$(date -u +%FT%TZ)" "$stage" "$rc" > "$ROOT/logs/model-exit.txt"' EXIT
printf 'start %s\n' "$(date -u +%FT%TZ)"
test -f "$ROOT/logs/setup-complete"
test ! -e "$ROOT/logs/models-started"
touch "$ROOT/logs/models-started"
test "$(git -C "$RFD2_ROOT" rev-parse HEAD)" = d365cbf4db3958814a9f8e4f6f94fa309dfebc2b
git -C "$RFD2_ROOT" diff --exit-code HEAD -- rf_diffusion fused_mpnn lib/chai
python3 - <<'CHECK_INPUT'
import hashlib,os,pathlib
p=pathlib.Path(os.environ['RA95_CONT'])/'reference.pdb'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='a08e12068a43923f0abd18de8f91c8a68f5b165cf63a36074675f6b597b0e84c'
rows={}
for line in p.read_text().splitlines():
 if line.startswith('ATOM  ') and line[12:16].strip()=='CA':
  rows[(line[21],int(line[22:26]))]=line[17:20]
assert len(rows)==150
for pos,res in [(24,'ASN'),(78,'LYS'),(112,'TYR'),(118,'TYR')]:
 assert rows[('A',pos)]==res,(pos,rows.get(('A',pos)))
for name in ['ligmpnn','protein_only','chai','chai_logs']:
 assert not (p.parent/name).exists(),name
print('input hash and four fixed identities verified',flush=True)
CHECK_INPUT
cd "$RFD2_ROOT"
stage=ligandmpnn
printf 'ligandmpnn_start %s\n' "$(date -u +%FT%TZ)"
apptainer exec --nv --bind "$ROOT:$ROOT" rf_diffusion/exec/mlfold.sif python -s -u fused_mpnn/run.py \
  --pdb_path "$RA95_CONT/reference.pdb" --fixed_residues "A24 A78 A112 A118" \
  --checkpoint_ligand_mpnn "$RFD2_ROOT/rf_diffusion/third_party_model_weights/ligand_mpnn/s25_r010_t300_p.pt" \
  --checkpoint_path_sc "$RFD2_ROOT/rf_diffusion/third_party_model_weights/ligand_mpnn/s_300756.pt" \
  --model_type ligand_mpnn --seed 43 --temperature 0.1 --batch_size 1 --number_of_batches 1 \
  --ligand_mpnn_use_atom_context 1 --ligand_mpnn_use_side_chain_context 1 \
  --pack_side_chains 1 --number_of_packs_per_design 1 --repack_everything 0 \
  --omit_AA XC --force_hetatm 1 --out_folder "$RA95_CONT/ligmpnn"
printf 'ligandmpnn_finished %s\n' "$(date -u +%FT%TZ)"
stage=sequence_validation
python3 - <<'CHECK_SEQ'
import hashlib,json,os,pathlib,re
root=pathlib.Path(os.environ['RA95_CONT'])
fastas=list((root/'ligmpnn/seqs').glob('*.fa'))
packed=list((root/'ligmpnn/packed').glob('*.pdb'))
assert len(fastas)==1,[str(x) for x in fastas]
assert len(packed)==1,[str(x) for x in packed]
records=[]
for line in fastas[0].read_text().splitlines():
 if line.startswith('>'): records.append([line[1:],''])
 elif line.strip(): records[-1][1]+=line.strip()
assert len(records)==2,records
made=[r for r in records if re.search(r'(?:^|[, ])id=1(?:,|$)',r[0])]
assert len(made)==1,records
seq=made[0][1]
assert len(seq)==150 and set(seq)<=set('ACDEFGHIKLMNPQRSTVWY'),seq
for pos,aa in {24:'N',78:'K',112:'Y',118:'Y'}.items(): assert seq[pos-1]==aa,(pos,seq[pos-1])
dest=root/'protein_only';dest.mkdir()
(dest/'design.fasta').write_text('>protein|ra95_design_1\n'+seq+'\n')
assert len(list(dest.iterdir()))==1
row={'fasta':str(fastas[0]),'packed_pdb':str(packed[0]),'generated_header':made[0][0],'sequence':seq,'length':len(seq),'sequence_sha256':hashlib.sha256(seq.encode()).hexdigest(),'fixed_positions':{'24':'N','78':'K','112':'Y','118':'Y'}}
(root/'sequence-check.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row),flush=True)
CHECK_SEQ
stage=chai
printf 'chai_start %s\n' "$(date -u +%FT%TZ)"
apptainer exec --nv --bind "$ROOT:$ROOT" rf_diffusion/exec/chai.sif python lib/chai/predict.py \
  --fasta_folder "$RA95_CONT/protein_only" --output_dir "$RA95_CONT/chai" \
  --log_dir "$RA95_CONT/chai_logs" --seed 43 --num_trunk_recycles 3 --num_diffn_timesteps 200 \
  --structure_output pdb cif --export_arrays --export_seed
printf 'chai_finished %s\n' "$(date -u +%FT%TZ)"
stage=complete

import collections, hashlib, json, pathlib, pickle, sys
import numpy as np
import torch
root = pathlib.Path('/home/ubuntu/ra95-reference-20260923')
trbs = list((root/'output').glob('*.trb'))
pdbs = list((root/'output').glob('*.pdb'))
assert len(trbs) == len(pdbs) == 1, (trbs, pdbs)
t = pickle.load(trbs[0].open('rb'))

def read_pdb(path):
    atoms = {}
    for line in path.read_text().splitlines():
        if line[:6] not in ('ATOM  ', 'HETATM'):
            continue
        if line[16] not in (' ', 'A') or line[76:78].strip() in ('H', 'D'):
            continue
        key = (line[21], int(line[22:26]), line[12:16].strip())
        assert key not in atoms, ('duplicate atom key', key)
        atoms[key] = {'resname':line[17:20].strip(), 'record':line[:6].strip(),
                      'xyz':np.array([float(line[i:i+8]) for i in (30,38,46)])}
    return atoms

def encode(x):
    if hasattr(x, 'tolist'): return x.tolist()
    return str(x)

source = pathlib.Path(t['config']['inference']['input_pdb'])
a, b = read_pdb(source), read_pdb(pdbs[0])
ref_keys = [tuple(x) for x in t['con_ref_pdb_idx']]
out_keys = [tuple(x) for x in t['con_hal_pdb_idx']]
expected = {('A',1051):('TYR',['OH','CZ']), ('A',1083):('LYS',['NZ','CE']),
            ('A',1110):('ASN',['OD1','CG','ND2']), ('A',1180):('TYR',['OH','CZ'])}
assert set(ref_keys) == set(expected)
assert len(set(out_keys)) == 4
mapping = []
motif_source, motif_output = [], []
for ref, out in zip(ref_keys, out_keys):
    residue, names = expected[ref]
    for name in names:
        ra, rb = a[(*ref,name)], b[(*out,name)]
        assert ra['resname'] == rb['resname'] == residue
        motif_source.append(ra['xyz']); motif_output.append(rb['xyz'])
    mapping.append({'source_author_id':list(ref), 'generated_id':list(out),
                    'residue':residue, 'atoms':names})

lig_a = {k[2]:v['xyz'] for k,v in a.items() if v['resname']=='LLK'}
lig_b = {k[2]:v['xyz'] for k,v in b.items() if v['resname']=='LLK'}
assert len({k[:2] for k,v in a.items() if v['resname']=='LLK'}) == 1
assert len({k[:2] for k,v in b.items() if v['resname']=='LLK'}) == 1
assert set(lig_a) == set(lig_b)
names = sorted(lig_a)
x, y = np.array([lig_b[n] for n in names]), np.array([lig_a[n] for n in names])
u,s,vt = np.linalg.svd((x-x.mean(0)).T @ (y-y.mean(0)))
d = np.eye(3); d[-1,-1] = np.linalg.det(u@vt)
r = u@d@vt
shift = y.mean(0) - x.mean(0)@r
lig_d = np.linalg.norm(x@r+shift-y,axis=1)
motif_d = np.linalg.norm(np.array(motif_output)@r+shift-np.array(motif_source),axis=1)
residues = sorted({k[:2] for k,v in b.items() if v['record']=='ATOM'})
assert len(residues) == 150
for residue in residues:
    for name in ('N','CA','C','O'):
        assert (*residue,name) in b
assert np.isfinite(np.array([v['xyz'] for v in b.values()])).all()
peptide = [float(np.linalg.norm(b[(*left,'C')]['xyz']-b[(*right,'N')]['xyz']))
           for left,right in zip(residues,residues[1:]) if left[0]==right[0] and right[1]==left[1]+1]
assert len(peptide)==149
cfg=t['config']
assert cfg['inference']['num_designs']==1 and cfg['inference']['seed_offset']==43
assert cfg['inference']['deterministic'] is True
assert cfg['contigmap']['length']=='150-150'
log=(root/'logs/native-run.log').read_text()
assert log.count('Making design ')==1
assert 'Flow-matching step: 100/100' in log
assert (root/'logs/native-run.exit').read_text().strip()=='0'
result = {
 'status':'native_reference_backbone_generated_and_mapping_checked',
 'scope':'Runtime and input-output consistency control; not catalytic activity or Atlas efficacy',
 'model_design_count':1,'seed':43,'flow_matching_steps':100,'device':t['device'],
 'protein_residue_count':len(residues),
 'protein_residue_counts':dict(collections.Counter(b[(*k,'CA')]['resname'] for k in residues)),
 'all_backbone_atoms_present':True,'all_coordinates_finite':True,
 'motif_mapping':mapping,'requested_motif_atom_count':len(motif_source),
 'source_comparison_selection':'Heavy atoms, alternate blank or A; source file unchanged',
 'ligand_atom_count':len(names),'ligand_atom_names':names,
 'ligand_aligned_rmsd_angstrom':float(np.sqrt(np.mean(lig_d**2))),
 'motif_rmsd_after_ligand_alignment_angstrom':float(np.sqrt(np.mean(motif_d**2))),
 'motif_max_displacement_after_ligand_alignment_angstrom':float(motif_d.max()),
 'metric_interpretation':'Conditioned geometry plus native postprocessing; not independent predictive or catalytic evidence',
 'consecutive_peptide_C_N_angstrom':{'count':len(peptide),'minimum':min(peptide),'median':float(np.median(peptide)),'maximum':max(peptide)},
 'native_idealization_rmsd':t.get('idealization_rmsd'),
 'runtime':{'python':sys.version,'torch':torch.__version__,'cuda':torch.version.cuda},
 'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'output_pdb_sha256':hashlib.sha256(pdbs[0].read_bytes()).hexdigest(),
 'output_trb_sha256':hashlib.sha256(trbs[0].read_bytes()).hexdigest(),
 'output_pdb':pdbs[0].name,'output_trb':trbs[0].name,
 'run_started_utc':(root/'logs/native-run.started').read_text().strip(),
 'run_finished_utc':(root/'logs/native-run.finished').read_text().strip(),
}
assert result['input_sha256']=='6dc747dbb1840892ed1f2f05e44d544a888db09336f4bb9df8b7732ace663682'
(root/'logs/output-checks.json').write_text(json.dumps(result,default=encode,indent=2)+'\n')
(root/'logs/resolved-inference-config.json').write_text(json.dumps(cfg,default=encode,indent=2)+'\n')
print(json.dumps(result,default=encode,indent=2))

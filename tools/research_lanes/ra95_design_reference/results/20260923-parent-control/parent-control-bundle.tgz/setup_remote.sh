#!/usr/bin/env bash
set -euo pipefail

ROOT="${RA95_PARENT_ROOT:-/home/ubuntu/ra95-parent-20260923}"
RFD2_ROOT="$ROOT/RFdiffusion2"
CHAI_DOWNLOADS_DIR="$ROOT/chai_downloads"
export ROOT RFD2_ROOT CHAI_DOWNLOADS_DIR

mkdir -p "$ROOT/logs"
exec > >(tee -a "$ROOT/logs/setup.log") 2>&1
printf 'setup_start %s\n' "$(date -u +%FT%TZ)"
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader
python3 - <<'PY'
import shutil
free = shutil.disk_usage('/home/ubuntu').free
assert free >= 100 * 1024**3, free
print('remote_free_bytes', free)
PY

if ! command -v apptainer >/dev/null; then
  sudo add-apt-repository -y ppa:apptainer/ppa
  sudo apt-get update -qq
  sudo apt-get install -y apptainer
fi
apptainer version

if [[ -e "$RFD2_ROOT" ]]; then
  test "$(git -C "$RFD2_ROOT" rev-parse HEAD)" = d365cbf4db3958814a9f8e4f6f94fa309dfebc2b
else
  git init "$RFD2_ROOT"
  git -C "$RFD2_ROOT" remote add origin https://github.com/RosettaCommons/RFdiffusion2.git
  git -C "$RFD2_ROOT" fetch --depth 1 origin d365cbf4db3958814a9f8e4f6f94fa309dfebc2b
  git -C "$RFD2_ROOT" checkout --detach FETCH_HEAD
fi
git -C "$RFD2_ROOT" diff --quiet HEAD -- lib/chai setup.py
mkdir -p "$RFD2_ROOT/rf_diffusion/exec" "$CHAI_DOWNLOADS_DIR/models/384"

# Fetch only the Chai container, conformer library and the five exports that the
# pinned source selects for a 258-token input. The export URLs are unversioned,
# so their observed sizes and hashes are frozen before prediction.
python3 - <<'PY'
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import urllib.request

root = Path(os.environ['ROOT'])
assets = [
    {
        'url': 'https://files.ipd.uw.edu/pub/rfdiffusion2/sifs/chai.sif',
        'path': 'RFdiffusion2/rf_diffusion/exec/chai.sif',
        'expected_bytes': 8396939264,
        'expected_sha256': '329c40f63572e99db23c550efe500a32ce861b59c755343b667929c5d4cec3f0',
    },
    {
        'url': 'https://chaiassets.com/chai1-inference-depencencies/conformers_v1.apkl',
        'path': 'chai_downloads/conformers_v1.apkl',
        'expected_bytes': 124726115,
        'expected_sha256': 'f2161256b565bbd84198da8b3e3d3978ae2f179f778d0995cd135c4c0c57c41f',
    },
]
for name in [
    'feature_embedding.pt2',
    'token_input_embedder.pt2',
    'trunk.pt2',
    'diffusion_module.pt2',
    'confidence_head.pt2',
]:
    assets.append({
        'url': f'https://chaiassets.com/chai1-inference-depencencies/models/384/{name}',
        'path': f'chai_downloads/models/384/{name}',
        'expected_bytes': None,
        'expected_sha256': None,
    })

def fetch(row):
    path = root / row['path']
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() or path.with_suffix(path.suffix + '.part').exists():
        raise RuntimeError(f'refusing pre-existing asset: {path}')
    tmp = path.with_suffix(path.suffix + '.part')
    digest = hashlib.sha256()
    size = 0
    req = urllib.request.Request(row['url'], headers={'User-Agent': 'ra95-parent-control/1'})
    print('downloading', row['url'], flush=True)
    try:
        with urllib.request.urlopen(req, timeout=120) as response, tmp.open('wb') as out:
            content_length = response.headers.get('Content-Length')
            while True:
                chunk = response.read(8 * 1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
                digest.update(chunk)
                size += len(chunk)
        actual_sha = digest.hexdigest()
        if row['expected_bytes'] is not None:
            assert size == row['expected_bytes'], (row['path'], size, row['expected_bytes'])
        if row['expected_sha256'] is not None:
            assert actual_sha == row['expected_sha256'], (row['path'], actual_sha)
        tmp.rename(path)
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise
    return {
        'url': row['url'],
        'path': row['path'],
        'bytes': size,
        'sha256': actual_sha,
        'http_content_length': int(content_length) if content_length else None,
        'identity_status': 'matched_prior_hash' if row['expected_sha256'] else 'freshly_frozen_before_prediction',
    }

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    rows = list(pool.map(fetch, assets))
(root / 'logs/direct-assets.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows, indent=2), flush=True)
PY

# Populate only the seven files used by the pinned ESM revision. The model is
# downloaded, but no Chai prediction or other model inference occurs here.
export APPTAINERENV_CHAI_DOWNLOADS_DIR="$CHAI_DOWNLOADS_DIR"
export APPTAINERENV_HF_HUB_DISABLE_TELEMETRY=1
apptainer exec --nv --bind "$ROOT:$ROOT" "$RFD2_ROOT/rf_diffusion/exec/chai.sif" python - <<'PY'
import os
from pathlib import Path
from huggingface_hub import snapshot_download

revision = '476b639933c8baad5ad09a60ac1a87f987b656fc'
files = [
    'config.json',
    'pytorch_model-00001-of-00002.bin',
    'pytorch_model-00002-of-00002.bin',
    'pytorch_model.bin.index.json',
    'special_tokens_map.json',
    'tokenizer_config.json',
    'vocab.txt',
]
path = snapshot_download(
    repo_id='facebook/esm2_t36_3B_UR50D',
    revision=revision,
    cache_dir=str(Path(os.environ['CHAI_DOWNLOADS_DIR']) / 'esm'),
    allow_patterns=files,
)
print('esm_snapshot', path)
PY

python3 - <<'PY'
import hashlib
import json
import os
from pathlib import Path

root = Path(os.environ['ROOT'])
revision = '476b639933c8baad5ad09a60ac1a87f987b656fc'
cache = root / 'chai_downloads/esm/models--facebook--esm2_t36_3B_UR50D'
(cache / 'refs').mkdir(parents=True, exist_ok=True)
(cache / 'refs/main').write_text(revision)
expected = {
    'config.json': (779, 'ca75d7053d1dcf2da6f0f5e4f2ff87d8929a7c39089e72ffbb0b5ddd4abf3a27'),
    'pytorch_model-00001-of-00002.bin': (9976735419, '0f971f11c449d21422aa982b791619c10351972992c735f4c3cd43fe09790412'),
    'pytorch_model-00002-of-00002.bin': (1390347055, '7560b46fc383c691fb74b915b7d4bcef40d3df181447f16ba4b298845e308d0c'),
    'pytorch_model.bin.index.json': (55493, '6b5790c484bc87e377dee81542cce94cf333a5d68fc02a6167b81b36aef612e0'),
    'special_tokens_map.json': (125, '3aedcd4211c0d43aec4e607ff60a63255f3174ead795e997350f09a5f8cd9ee1'),
    'tokenizer_config.json': (95, '7e9161ecdb548ec45a41cbc6b24aa4476fdd418461f491c4207baa99419a29ad'),
    'vocab.txt': (93, '0b82cc0a7c7cf9e567b1e5892d793285b9fbae822c964ca48696f7db44598e03'),
}
rows = []
for name, (expected_size, expected_sha) in expected.items():
    path = cache / 'snapshots' / revision / name
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as handle:
        while chunk := handle.read(8 * 1024 * 1024):
            digest.update(chunk)
            size += len(chunk)
    actual_sha = digest.hexdigest()
    assert (size, actual_sha) == (expected_size, expected_sha), (name, size, actual_sha)
    rows.append({
        'source_url': f'https://huggingface.co/facebook/esm2_t36_3B_UR50D/resolve/{revision}/{name}',
        'path': str(path.relative_to(root)),
        'bytes': size,
        'sha256': actual_sha,
        'revision': revision,
    })
ref = cache / 'refs/main'
assert ref.read_text() == revision
rows.append({
    'path': str(ref.relative_to(root)),
    'bytes': ref.stat().st_size,
    'sha256': hashlib.sha256(ref.read_bytes()).hexdigest(),
    'content': revision,
})
(root / 'logs/esm-assets.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows, indent=2), flush=True)
PY

apptainer exec --nv --bind "$ROOT:$ROOT" "$RFD2_ROOT/rf_diffusion/exec/chai.sif" \
  python -c 'import torch; assert torch.cuda.is_available(); print(torch.__version__, torch.cuda.get_device_name(0))'
printf '%s\n' setup_complete > "$ROOT/logs/setup-complete"
printf 'setup_finished %s\n' "$(date -u +%FT%TZ)"

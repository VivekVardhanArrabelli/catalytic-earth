#!/usr/bin/env bash
set -euo pipefail

ROOT="${RA95_PARENT_ROOT:-/home/ubuntu/ra95-parent-20260923}"
RFD2_ROOT="$ROOT/RFdiffusion2"
CHAI_DOWNLOADS_DIR="$ROOT/chai_downloads"
INPUT_DIR="$ROOT/input"
OUTPUT_DIR="$ROOT/output/chai"
LOG_DIR="$ROOT/output/chai_logs"
PYTHONPATH="$RFD2_ROOT${PYTHONPATH:+:$PYTHONPATH}"
export ROOT RFD2_ROOT CHAI_DOWNLOADS_DIR INPUT_DIR OUTPUT_DIR LOG_DIR PYTHONPATH

mkdir -p "$ROOT/logs"
stage=preflight
exec > >(tee "$ROOT/logs/parent.log") 2>&1
trap 'rc=$?; printf "%s %s %s\n" "$(date -u +%FT%TZ)" "$stage" "$rc" > "$ROOT/logs/parent-exit.txt"' EXIT
printf 'parent_start %s\n' "$(date -u +%FT%TZ)"

test -f "$ROOT/logs/setup-complete"
test -f "$ROOT/logs/direct-assets.json"
test -f "$ROOT/logs/esm-assets.json"
test ! -e "$ROOT/logs/parent-started"
test ! -e "$OUTPUT_DIR"
test ! -e "$LOG_DIR"
test "$(git -C "$RFD2_ROOT" rev-parse HEAD)" = d365cbf4db3958814a9f8e4f6f94fa309dfebc2b
git -C "$RFD2_ROOT" diff --quiet HEAD -- lib/chai setup.py
nvidia-smi --query-gpu=name,memory.total,memory.free,driver_version --format=csv,noheader

# Rehash every runtime asset and the exact 258-residue parent input. This
# receipt is written before the single prediction invocation below.
python3 - <<'PY'
import datetime
import hashlib
import json
import os
from pathlib import Path

root = Path(os.environ['ROOT'])
fasta = Path(os.environ['INPUT_DIR']) / 'ra95_5_8f_parent.fasta'
expected_file_sha = 'cbba0f396a63b32b7d12189a203f2ec39be62ea99c83afad7ec4a6133c0fe1d5'
expected_seq_sha = 'b842c993f9e9e3e80cffb546e6c8b5142541953e89b0bf4ddcfdfcb6aae0297b'
assert fasta.is_file()
assert hashlib.sha256(fasta.read_bytes()).hexdigest() == expected_file_sha
lines = fasta.read_text().splitlines()
assert lines[0] == '>protein|ra95_5_8f_parent'
sequence = ''.join(line.strip() for line in lines[1:] if line.strip())
assert len(sequence) == 258
assert hashlib.sha256(sequence.encode()).hexdigest() == expected_seq_sha
assert set(sequence) <= set('ACDEFGHIKLMNPQRSTVWY')
assert sorted(p.name for p in Path(os.environ['INPUT_DIR']).iterdir()) == [fasta.name]
assert min(size for size in [256, 384, 512, 768, 1024, 2048] if len(sequence) <= size) == 384

verified = []
for inventory_name in ['direct-assets.json', 'esm-assets.json']:
    rows = json.loads((root / 'logs' / inventory_name).read_text())
    for row in rows:
        path = root / row['path']
        digest = hashlib.sha256()
        size = 0
        with path.open('rb') as handle:
            while chunk := handle.read(8 * 1024 * 1024):
                digest.update(chunk)
                size += len(chunk)
        assert size == row['bytes'], (row['path'], size, row['bytes'])
        assert digest.hexdigest() == row['sha256'], (row['path'], digest.hexdigest(), row['sha256'])
        verified.append({'path': row['path'], 'bytes': size, 'sha256': digest.hexdigest()})

exports = [row for row in verified if row['path'].startswith('chai_downloads/models/384/')]
assert sorted(Path(row['path']).name for row in exports) == sorted([
    'feature_embedding.pt2', 'token_input_embedder.pt2', 'trunk.pt2',
    'diffusion_module.pt2', 'confidence_head.pt2',
])
receipt = {
    'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'rfdiffusion2_commit': 'd365cbf4db3958814a9f8e4f6f94fa309dfebc2b',
    'input': {
        'path': str(fasta.relative_to(root)),
        'file_sha256': expected_file_sha,
        'sequence_length': 258,
        'sequence_sha256': expected_seq_sha,
        'selected_export_size': 384,
    },
    'assets': verified,
    'prediction_settings': {
        'seed': 43,
        'num_trunk_recycles': 3,
        'num_diffn_timesteps': 200,
        'expected_model_indices': [0, 1, 2, 3, 4],
    },
}
(root / 'logs/preprediction-assets.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2), flush=True)
PY

touch "$ROOT/logs/parent-started"
export CHAI_DOWNLOADS_DIR
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export APPTAINERENV_CHAI_DOWNLOADS_DIR="$CHAI_DOWNLOADS_DIR"
export APPTAINERENV_HF_HUB_OFFLINE=1
export APPTAINERENV_TRANSFORMERS_OFFLINE=1
export APPTAINERENV_PYTHONPATH="$PYTHONPATH"

stage=chai
printf 'chai_start %s\n' "$(date -u +%FT%TZ)"
cd "$RFD2_ROOT"
apptainer exec --nv --bind "$ROOT:$ROOT" rf_diffusion/exec/chai.sif \
  python lib/chai/predict.py \
  --fasta_folder "$INPUT_DIR" \
  --output_dir "$OUTPUT_DIR" \
  --log_dir "$LOG_DIR" \
  --seed 43 \
  --num_trunk_recycles 3 \
  --num_diffn_timesteps 200 \
  --structure_output pdb cif \
  --export_arrays \
  --export_seed
printf 'chai_finished %s\n' "$(date -u +%FT%TZ)"

stage=output_validation
python3 - <<'PY'
import datetime
import hashlib
import json
import os
from pathlib import Path

root = Path(os.environ['ROOT'])
output = Path(os.environ['OUTPUT_DIR'])
stem = 'ra95_5_8f_parent'
expected_indices = list(range(5))
for suffix in ['pdb', 'cif']:
    found = sorted(int(path.stem.rsplit('_', 1)[1]) for path in output.glob(f'pred.{stem}_model_idx_*.{suffix}'))
    assert found == expected_indices, (suffix, found)
scores = sorted(output.glob(f'scores.{stem}_model_idx_*.json'))
assert [int(path.stem.rsplit('_', 1)[1]) for path in scores] == expected_indices
for path in scores:
    row = json.loads(path.read_text())
    assert row.get('seed') == 43, (path, row.get('seed'))
    assert 'pae_array' in row and 'plddt_array' in row, path
rows = []
for path in sorted(p for p in output.rglob('*') if p.is_file()):
    data = path.read_bytes()
    rows.append({
        'path': str(path.relative_to(root)),
        'bytes': len(data),
        'sha256': hashlib.sha256(data).hexdigest(),
    })
receipt = {
    'validated_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'model_indices': expected_indices,
    'pdb_count': 5,
    'cif_count': 5,
    'score_json_count': 5,
    'files': rows,
}
(root / 'logs/parent-outputs.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2), flush=True)
PY

stage=complete
printf 'parent_complete %s\n' "$(date -u +%FT%TZ)"

#!/usr/bin/env python3
"""Preserve this one parent run; exclude downloaded model/container bytes."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

root = Path('/home/ubuntu/ra95-parent-20260923')
repo = root / 'RFdiffusion2'

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()

identity = {
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'revision': git('rev-parse', 'HEAD'),
    'tracked_diff': git('diff', 'HEAD'),
    'git_status_tracked': git('status', '--porcelain', '--untracked-files=no'),
    'gpu': subprocess.check_output([
        'nvidia-smi', '--query-gpu=name,memory.total,driver_version',
        '--format=csv,noheader'], text=True).strip(),
    'apptainer_version': subprocess.check_output(['apptainer', 'version'], text=True).strip(),
}
(root / 'logs/source-and-gpu.json').write_text(json.dumps(identity, indent=2) + '\n')
files = sorted(
    [p for folder in ('input', 'output', 'logs')
     for p in (root / folder).rglob('*') if p.is_file()]
    + [root / name for name in ('setup_remote.sh', 'run_parent.sh', 'preserve_remote.py')]
)
assert all(p.is_file() and not p.is_symlink() for p in files)
assert len(files) == len(set(files))
rows = [{'path': str(p.relative_to(root)), 'bytes': p.stat().st_size,
         'sha256': sha(p)} for p in files]
manifest = root / 'MANIFEST.json'
manifest.write_text(json.dumps(rows, indent=2) + '\n')
archive = root / 'parent-control-bundle.tgz'
with tarfile.open(archive, 'w:gz') as bundle:
    for p in files + [manifest]:
        bundle.add(p, arcname=str(p.relative_to(root)), recursive=False)
receipt = {'bundle': archive.name, 'bytes': archive.stat().st_size,
           'sha256': sha(archive), 'members': len(files) + 1}
(root / 'bundle-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
